import React, { Component } from "react";
import {
  FormGroup,
  FormControl,
  ControlLabel
} from "react-bootstrap";
import LoaderButton from "./LoaderButton";
import "../Signup.css";

export default class EditSkillProficiency  extends Component {
  constructor(props) {
    super(props);
    // this.onChangeSkillId = this.onChangeSkillId.bind(this);
    
    this.state = {
      isLoading: false,
      skills: [],
      users: [],
      planets: [],
      cgempID: this.props.location.state.editEmpSkill.cg_emp_id,
      emp_name:this.props.location.state.editEmpSkill.emp_name,
      skill:this.props.location.state.editEmpSkill.skill,
      skill_id:this.props.location.state.editEmpSkill.skill_id,
      proficiency: this.props.location.state.editEmpSkill.proficiency,
      last_used: this.props.location.state.editEmpSkill.last_used,
      experience: this.props.location.state.editEmpSkill.experience,
       };
    
    
  }

  validateForm() {
    return (
      this.state.email.length > 0 &&
      this.state.employeeId.length > 0 &&
      this.state.password.length > 0 &&
      this.state.password === this.state.confirmPassword 
    );
  }

  /*validateConfirmationForm() {
    return this.state.confirmationCode.length > 0;
  }*/

  
  componentDidMount() {
       
    fetch('http://localhost:5000/getEmployeeName')
        .then(res => res.json())
        .then(data => {
            //console.log(data);
            // console.log("Selected Data"+data.results[0])
            this.setState({
                planets: data,


            });
            console.log(data.recordset[0]);
        })
        .catch(err => console.error);


    fetch("http://localhost:5000/skillslist")
        .then(res => res.json())
        .then(data => {
            this.setState({
                skills: data

            });
            console.log(data.recordset[0]);
        })
        .catch(err => console.error);


}

handleChange = event => {
  this.setState({
   [event.target.id]: event.target.value
   });
   
}


// onChangeSkillId =e=>{
//   var index = e.target.selectedIndex;
//   console.log(e.target.childNodes[index].getAttribute('skill-id'));

//   this.setState({
//       skill_id: e.target.childNodes[index].getAttribute('skill-id'),
//       skill: e.nativeEvent.target[index].text
//   });
// }

  handleSubmit = event => {
    event.preventDefault();
    console.log("hi Lead");
    fetch('http://localhost:5000/editupdate',
{
method: 'PUT',
headers: {
Accept: 'application/json',
'Content-Type': 'application/json'
},
body: JSON.stringify({
"CG_EMP_ID":parseInt(this.state.cgempID), 
"SKILL_ID":parseInt(this.state.skill_id),
"PROFICIENCY":this.state.proficiency,
"LAST_USED":this.state.last_used, 
"EXPERIENCE":parseInt(this.state.experience), 
})
}).then(res => res.json())
.then(resData => {
console.log(resData);    
})
.catch(err => console.error); 
fetch("http://localhost:5000/viewSkillproficiency")
.then(res => res.json())
.then(data => {
   this.setState({
    employees: data
    
}); 
   // console.log(data.recordset[0]);
   this.props.history.push('/ViewSkillProficiency'); 
})
  
} 



  
  renderForm() {
    let emps = this.state.planets;
    // console.log("Render"+this.state.planets);
    let optionItems_employee = emps.map((planet) =>
        <option value={planet.EMP_NAME} data-id={planet.CG_EMP_ID} key={planet.CG_EMP_ID}>{planet.EMP_NAME}</option>

    );

    let skill = this.state.skills;
    // console.log(skill);
    let optionItems_skills = skill.map((empskill) =>
        <option value={empskill.SKILL} skill-id={empskill.SKILL_ID} key={empskill.SKILL_ID}>{empskill.SKILL}</option>
    );


    return (
      <form onSubmit={this.handleSubmit}>

       {/* <label hidden> {this.state.cg_emp_id}</label> */}
 
          <FormGroup controlId="emp_name" bsSize="large" readOnly='true'>
          <ControlLabel>Employee Name:</ControlLabel>
          <select value={this.state.emp_name} onChange={this.onChangeCGempName} className="form-control" readOnly >
                         {optionItems_employee}
         </select>
          </FormGroup>
       
      
        <FormGroup controlId="skill" bsSize="large" readOnly='true'>
          <ControlLabel>Skill:</ControlLabel>
          <select value={this.state.skill} onChange={this.onChangeSkillId} className="form-control" readOnly>
                            {optionItems_skills}
            </select>
            </FormGroup>
                      
    
        <FormGroup controlId="proficiency" bsSize="large">
          <ControlLabel>Proficiency:</ControlLabel>
          <FormControl
            value={this.state.proficiency}
            onChange={this.handleChange}
            type="string"
          />
        </FormGroup>
        <FormGroup controlId="last_used" bsSize="large">
          <ControlLabel>Last Used:</ControlLabel>
          <FormControl
            value={this.state.last_used}
            onChange={this.handleChange}
            type="number"
          />
        </FormGroup>
        <FormGroup controlId="experience" bsSize="large">
          <ControlLabel>Experience</ControlLabel>
          <FormControl
            value={this.state.experience}
            onChange={this.handleChange}
            type="number"
          />
        </FormGroup>
                  
        <LoaderButton
          block
          bsSize="large"
          // disabled={!this.validateForm()}
          type="submit"
          isLoading={this.state.isLoading}
          text="Save"
          loadingText="Saving…"
        /> 
      </form>
    );
  }

  render() {
    return (
      <div className="Signup">
       {this.renderForm()}
      </div>
  
    );
  }
}
