import React, { Component } from "react";

import { FormGroup, FormControl, ControlLabel } from "react-bootstrap";
import LoaderButton from "./components/LoaderButton";
// import data from "./components/LoginInfo";


import "./Login.css";


export default class Login extends Component {
  constructor(props) {
    super(props);
    
    this.state = {
      isLoading: false,
      email: "",
      password: "",
      role:"",
      emailError:"",
      passwordError:"",
      dataError:"",
      employee:[]
    };
    
  }

  validateForm() {
   let emailError="";
    let passwordError="";
    if(!this.state.email.includes("@")){
      emailError="Invalid Email"
    }
    if(!this.state.password){
      passwordError="Password shouldn't be empty"
    }
    if(emailError || passwordError){
      this.setState({emailError,passwordError});
      return false;
    }
   
    return true;
  }

  handleChange = event => {
    this.setState({
      [event.target.id]: event.target.value
    });
  }

  
  handleSubmit = event => {
    event.preventDefault();
    const isValid=this.validateForm();
    
    this.setState({ isLoading: true });
    if(isValid){
    try {
      console.log("Fetching");
      var ikeamailid=this.state.email;
      var pass=this.state.password;
      var roles= this.state.role;
      
      fetch('http://localhost:5000/employee/'+ikeamailid+'/'+pass)
              .then(res => res.json())
              .then(data => {
                  if(this.state.email===data[0].CG_EMAILID && this.state.password===data[0].password){
                this.props.userHasAuthenticated(true,data[0].ROLE);
               sessionStorage.setItem("userName",data[0].EMP_NAME);
               sessionStorage.setItem("userRole", data[0].ROLE);
               sessionStorage.setItem("cgempid", data[0].CG_EMP_ID);
              
              this.props.history.push({pathname:"/welcome",
              state: {
                username:data[0].EMP_NAME,
                role:data[0].ROLE
               }
              });
              
            }

              })
              .catch(err => this.setState({dataError:"Invalid Email or password"}));
    console.log(this.state.employee);
    } catch (e) {
      alert(e.message);
      this.props.history.push("/");
      this.setState({ isLoading: false });
      this.props.history.push("/");
    }
    this.setState({emailError:"",passwordError:""});
  }
  }
  

  render() {
    return (
     
     
      <form onSubmit={this.handleSubmit} className="form1">
        
        <div className="row">
          <div className="form-inline col-md-6">
          <label htmlFor="email" className="labelLogin">Email: </label>
          </div>
          <div className="form-inline col-md-6">
          <input type="email" value={this.state.email}
            onChange={this.handleChange}
            type="email" id="email"/>
          </div>
          </div>
          <div className="message">{this.state.emailError}</div>
          <br/>
          <div className="row">
          <div className="form-inline col-md-6">
          <label htmlFor="password" className="labelLogin">Password: </label>
          </div>
          <div className="form-inline col-md-6">
          <input type="password" value={this.state.password}
            onChange={this.handleChange}
            type="password" id="password"/>
          </div>
          </div>
          <div className="message">{this.state.passwordError}</div>
          <div className="message">{this.state.dataError}</div>
          <br/>
          <div>
        <label>
         <input type="submit" value="Login" id="button" className="buttonLogin"/>
         </label>
        </div> 
        
          </form>
         
          
      /* <div className="Login">
        <form onSubmit={this.handleSubmit}>
          <FormGroup controlId="email" bsSize="large">
            <ControlLabel>Email</ControlLabel>
            <FormControl
              autoFocus
              //type="email"
              type="text"
              value={this.state.email}
              onChange={this.handleChange}
            />
          </FormGroup>
          <FormGroup controlId="password" bsSize="large">
            <ControlLabel>Password</ControlLabel>
            <FormControl
              value={this.state.password}
              onChange={this.handleChange}
              type="password"
            />
          </FormGroup>
          <LoaderButton
  block
  bsSize="large"
  disabled={!this.validateForm()}
  type="submit"
  isLoading={this.state.isLoading}
  text="Login"
  loadingText="Logging in…"
/> 

        </form>
      </div> */
      
    );
  }
}
