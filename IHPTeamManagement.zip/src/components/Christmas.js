
import React from 'react';
import img1 from '../xmas/xmas-1.jpg';
import img2 from '../xmas/xmas-2.jpg';
import img4 from '../xmas/xmas-4.jpg';
import img5 from '../xmas/xmas-5.jpg';
import img6 from '../xmas/xmas-6.jpg';
import img3 from '../xmas/xmas-3.jpg';
import xmas from '../xmas/download.jpg';

import '../xmas.css';


export default class Christmas extends React.Component {
    render() {
        return (
            <div>
                  <h4 align="center"><img class="icon" src={xmas}></img><u>Celebration On Christmas</u><img class="icon" src={xmas}></img></h4>
         <table>
             <tr>
                 <td><img class="size"src={img1}></img></td>  
                 <td><img class="size"src={img2}></img></td> 
                
                 <td><img class="size"src={img4}></img></td>
                 <td><img class="size"src={img5}></img></td> 
               
                 </tr>
                 <tr>
                 <td><img class="size"src={img6}></img></td>  
                 <td><img class="size"src={img3}></img></td>
                
               
                 </tr>
         </table>
         </div>
        );
    }
   
}




