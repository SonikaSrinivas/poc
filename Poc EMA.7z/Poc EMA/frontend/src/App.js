import React, { Component } from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Switch} from 'react-router-dom';
import Header from './components/layout/Header';
import Home from './components/pages/Home';
import ListofEvent from './components/Event/ListofEvent';
import AddEvent from './components/Event/AddEvent'
import Notification from './components/pages/Notification';
import EventDetails from './components/Event/EventDetails';
import Eventregistration from './components/Event/Eventregistration';
import Login from './components/pages/Login';
import Register from './components/pages/Register';




class App extends Component {
  render() {
    return (
     <Router>
       <div>
         <Header  />
         <div className="container">
         <Switch>
           <Route exact path="/home" component={Home} />
           <Route exact path="/addEvent" component={AddEvent} />
           <Route exact path="/listofevent" component={ListofEvent} />
           <Route exact path="/notification" component={Notification} />
           <Route exact path="/event/:_id" component={EventDetails} />
           <Route exact path="/eventregistration/" component={Eventregistration} />
           
           <Route exact path="/login" component={Login} />
           <Route exact path="/register" component={Register} />
           
         </Switch>
         </div>
       </div>
     </Router>
    );
  }
}

export default App;
