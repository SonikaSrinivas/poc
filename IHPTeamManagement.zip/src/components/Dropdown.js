



import React from 'react';
 import Edit from '@material-ui/icons/Edit';
import Delete from '@material-ui/icons/Delete';
import {Link} from 'react-router-dom' ; 
import {
    HelpBlock,
    FormGroup,
    FormControl,
    ControlLabel
    } from "react-bootstrap";  
import DatePicker from "react-datepicker"; 
import "react-datepicker/dist/react-datepicker.css";
 

class Dropdown extends React.Component {
    constructor(props){
        super(props);
              this.state={
              employees: [],
              employeeId:"",
              planets: [],
              empname:"",
              startDate: "",
              endDate:""
                       };
          this.onChangeCGempId = this.onChangeCGempId.bind(this);
        }

        onChangeCGempId(e) {
          var index = e.target.selectedIndex;
          this.setState({
      
              cg_emp_id: e.target.childNodes[index].getAttribute('data-id')
          });
      
      
      }
        componentDidMount()
        {
          document.getElementById("datatable").style.visibility ="hidden"
            fetch("http://localhost:5000/getEmployeeName")
            .then(res => res.json())
            .then(data => {
                this.setState({
                    planets: data
    
                });
                console.log(data.recordset[0]);
            })
            .catch(err => console.error);
    
        fetch("http://localhost:5000/skillslist")
            .then(res => res.json())
            .then(data => {
                this.setState({
                    skills: data
    
                });
                console.log(data.recordset[0]);
            })
            .catch(err => console.error);
        }
        editSkillprof=id=>event=>{
          event.preventDefault();
          console.log("Fetching"+id);
          fetch("http://localhost:5000/editlms/"+id)
                  .then(res => res.json())
                  .then(data => {
                    console.log("DATAAAA"+data[0]);                     
                    this.props.history.push({pathname:"/Editlms",
                    state: {
                      editEmpSkill:data[0]
                      
                     }
                     
                     
                    });
                  
                    
                  })
                  .catch(err => console.error);
                }

        getEmployees= () =>{
            //let id = this.state.cg_emp_id;
            fetch('http://localhost:5000/lms')
            .then(response => response.json())
            .then(data => {
                this.setState({
                  employees: data
                  });   
                  console.log(data);
            })
      .catch(err =>  console.error(err))
          }

          handleChange = event => {
            this.setState({value: event.target.value});
            this.setState({cg_emp_id: event.target.childNodes[event.target.selectedIndex].getAttribute('data-id')});
            } 


            handleStartDateChange = date => {
           this.setState({
                startDate: date
              });
             
            }
              handleEndDateChange = date => {
               this.setState({
                endDate: date
              });
              } 

            handleSubmit = event => {
              document.getElementById("datatable").style.visibility ="visible"
              this.getEmployees();   
                event.preventDefault();
                
               fetch('http://localhost:5000/lms',
            {
            method: 'POST',
            headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json'
            },
            body: JSON.stringify({                    
            "CG_EMP_ID":parseInt(this.state.cg_emp_id),
            "Emp_NAME":this.state.value,
            "L_START_DATE":this.state.startDate,
            "L_END_DATE":this.state.endDate
            
            })
            }).then(res => res.json())
            .then(resData => {
            console.log(resData);
            // this.fetchOrders();
            })
            
            .catch(err => console.error);
            }
           
            renderEmployees =({name})=><div key={name}></div>
    render() {

      let emps = this.state.planets;
      console.log(emps);
      
       
    
      let optionItems_employee = emps.map((planet) =>
        <option data-id={planet.CG_EMP_ID} value ={planet.EMP_NAME}>{planet.EMP_NAME}</option>
           );
           
        return(
<div>
      
          <form onSubmit={this.handleSubmit}>
          <table  border="1" align="center" > 
        <tr><td>  <label>
          Employee Name:  </label> </td>
         <td><label>
            Start Date:  </label></td>
<td>            <label>End  Date:  </label> </td>
</tr><tr><td>

            <select  width ='80' name="employee-select" onChange={this.handleChange}>
                <option>Select Employee</option>
             {optionItems_employee}
             </select></td>
            
           <td>
             <DatePicker
            name ="start"
        selected={this.state.startDate}
        onChange={this.handleStartDateChange}
      /></td>
         
               
         <td>
              <DatePicker
                  name ="end"
           selected={this.state.endDate}
        onChange={this.handleEndDateChange} /> </td>
         
         <td> <input type="submit" value="Submit" /> </td>
         </tr>
        
          </table>
        </form>
      
<br></br>
        <table id ="datatable"  border="1" align='center'>
<tr>
<th>EMP_NAME</th>
<th>Lms  Start Date</th>
<th>Lms  End Date</th>
<th>Actions</th></tr>
{this.state.employees.map(row => (
<tr key={row.EMP_NAME}>
<td>{row.EMP_NAME}</td>
<td>{row.STARTDATE}</td>
<td>{row.ENDDATE}</td>
 <td><a><Edit>edit</Edit></a> 
 <a><Delete>delete</Delete></a>
 </td> 
</tr>
))}
</table> 


</div>
           


        
        )
    }

    }

export default Dropdown;