import React, { Component } from "react";
import {
  FormGroup,
  FormControl,
  ControlLabel
} from "react-bootstrap";
import LoaderButton from "./components/LoaderButton";
import "./Signup.css";


export default class EditTeamInfo extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      employeeId:this.props.location.state.teamInfoKey.CG_EMP_ID,
      empname:this.props.location.state.teamInfoKey.EMP_NAME,
      email: this.props.location.state.teamInfoKey.CG_EMAILID,
      password: this.props.location.state.teamInfoKey.password,
      confirmPassword: this.props.location.state.teamInfoKey.password,
      ikeashortid:this.props.location.state.teamInfoKey.IKEA_USER_ID,
      ikeaemail:this.props.location.state.teamInfoKey.IKEA_MAILID,
      band:this.props.location.state.teamInfoKey.BAND,
      role:this.props.location.state.teamInfoKey.ROLE,
      confirmPasswordEnd: "",
      //confirmationCode: "",
      newUser: null,
      
    };
    
    
  }

  validateForm() {
    let employeeIdError="";
    let empnameError="";
    let emailError="";
    let ikeaemailError="";
    let ikeashortidError="";
    let bandError="";
    let roleError="";
    let passwordError="";
    let confirmPasswordError="";
    

    if(!this.state.employeeId){
      employeeIdError="Employee ID should not be empty";
    }
    if(!this.state.empname || this.state.empname.match(/[0-9]/))
    {
      empnameError="Invalid Employee Name";
    }
    if(!this.state.email.includes("@")){
      emailError="Invalid Email"
    }
    if(!this.state.ikeaemail.includes("@")){
      ikeaemailError="Invalid Ikea Email"
    }
    if(!this.state.ikeashortid){
      ikeashortidError="Ikea short id shouldn't be empty"
    }
    if(!this.state.band){
      bandError="Band shouldn't be empty"
    }
    if(!this.state.role){
      roleError="Role shouldn't be empty"
    }

    if(!this.state.password){
      passwordError="Password shouldn't be empty"
    }

    if(!this.state.confirmPassword || (this.state.confirmPassword!==this.state.password)){
      confirmPasswordError="Confirm Password should match with password"
    }

    
    if(employeeIdError || empnameError || emailError || ikeaemailError || ikeashortidError || bandError || roleError){
      this.setState({employeeIdError,empnameError,emailError,ikeaemailError,ikeashortidError,bandError,roleError,passwordError,confirmPasswordError});
      return false;
    }
   
    return true;
  }

  /*validateConfirmationForm() {
    return this.state.confirmationCode.length > 0;
  }*/

  handleChange = event => {
    this.setState({
     [event.target.id]: event.target.value
     });
     
  }

  handleSubmit = event => {
    event.preventDefault();
    const isValid=this.validateForm();
    if(isValid){
    console.log("hi Lead");
    fetch('http://localhost:5000/employees',
{
method: 'PUT',
headers: {
Accept: 'application/json',
'Content-Type': 'application/json'
},
body: JSON.stringify({
"CG_EMP_ID":parseInt(this.state.employeeId), 
"EMP_NAME":this.state.empname, 
"CG_USER_ID":"Jaib",
"CG_EMAILID":this.state.email,
"IKEA_USER_ID":this.state.ikeashortid, 
"IKEA_MAILID":this.state.ikeaemail, 
"BAND":this.state.band, 
"PROJECT_CD":100516305,
"PROJ_ROLE":this.state.role, 
"START_DATE":"2017-04-03 00:00:00", 
"END_DATE":"2017-05-03 00:00:00", 
"ROLE":"User",
"password":this.state.password,
"delete_flag":"E",
})
}).then(res => res.json())
.then(resData => {
console.log(resData);
// this.fetchOrders();

})
.catch(err => console.error); 
fetch("http://localhost:5000/teaminfo")
  .then(res => res.json())
  .then(data => {
    this.setState({
      teaminfo: data
      
  }); 
      //console.log(data.recordset[0]);
      this.props.history.push('/TeamInfo'); 
  })
  .catch(err => console.error);

  
} 
  }



  
renderForm() {
  return (
  
    <form onSubmit={this.handleSubmit}>
      
  <div className="row">
 <div className="form-inline col-md-6">
 <div className="row">
   <div className="col-md-3">
        <label htmlFor="employeeId" className="labelLeft">Employee ID: </label>
  </div>
  <div className="col-md-9">
        <input type="text" value={this.state.employeeId}
          onChange={this.handleChange}
          type="number" id="employeeId" className="inputLeft"/>
   </div> 
   <div className="messageLeft">{this.state.employeeIdError}</div>
   </div>      
   </div>  
   <div className="form-inline col-md-6">
   <div className="row">
   <div className="col-md-3">
        <label for="empname" className="labelRight">Name: </label>
    </div>
    <div className="col-md-9">
        <input type="text" value={this.state.empname}
          onChange={this.handleChange}
          type="string" id="empname" className="inputRight"/>
      </div> 
      <div className="messageRight">{this.state.empnameError}</div>
      </div>   
      </div>     
      </div>
      <br/>
      
      
      
      
      
      
      
      <div className="row">
        <div className="form-inline col-md-6">
        <div className="row">
          <div className="col-md-3">
        <label htmlFor="email" className="labelLeft">Email: </label>
        </div>
        <div className="col-md-9">
        <input type="email" value={this.state.email}
          onChange={this.handleChange}
          type="email" id="email" className="inputLeft"/>
          </div>
          <div className="messageLeft">{this.state.emailError}</div>
          </div>
          </div>
          <div className="form-inline col-md-6">
            <div className="row">
            <div className="col-md-3">   
        <label htmlFor="ikeaemail" className="labelRight">Ikea Email: </label>
        </div>
        <div className="col-md-9">
        <input type="email" value={this.state.ikeaemail}
          onChange={this.handleChange}
          type="email" id="ikeaemail" className="inputRight"/>
          </div>
          <div className="messageRight">{this.state.ikeaemailError}</div>
      </div>
      </div>
      </div>
      <br/>
      
      <div className="row">
        <div className="form-inline col-md-6">
        <div className="row">
        <div className="col-md-3">
        <label htmlFor="ikeashortid" className="labelLeft">Ikea Short ID: </label>
        </div>
        <div className="col-md-9">
        <input type="string" value={this.state.ikeashortid}
          onChange={this.handleChange}
          type="string" id="ikeashortid" className="inputLeft"/>
          </div>
          <div className="messageLeft">{this.state.ikeashortidError}</div>
          </div>
          </div>
          <div className="form-inline col-md-6">
          <div className="row">
          <div className="col-md-3">
        <label htmlFor="band" className="labelRight">Band: </label>
        </div>
        <div className="col-md-9">
        <input type="string" value={this.state.band}
          onChange={this.handleChange}
          type="string" id="band" className="inputRight"/>
          </div>
          <div className="messageRight">{this.state.bandError}</div>
      </div>
      </div>
      </div>
      <br/>
      

      
      <div className="row">
        <div className="form-inline col-md-6">
        <div className="row">
        <div className="col-md-3">
        <label htmlFor="role" className="labelLeft"> Role: </label>
        </div>
        <div className="col-md-9">
        <input type="string" value={this.state.role}
          onChange={this.handleChange}
          type="string" id="role" className="inputLeft"/>
          </div>
          <div className="messageLeft">{this.state.roleError}</div>
          </div>
          </div>
          <div className="form-inline col-md-6">
            <div className="row">
            <div className="col-md-3">
        <label htmlFor="password" className="labelRight">Password: </label>
        </div>
        <div className="col-md-9">
        <input type="password" value={this.state.password}
          onChange={this.handleChange}
          type="password" id="password" className="inputRight"/>
          </div>
          <div className="messageRight">{this.state.passwordError}</div>
      </div>
      </div>
      </div>
      <br/>


      <div className="row">
        <div className="form-inline col-md-6">
        <div className="row">
          <div className="col-md-3">
        <label htmlFor="confirmPassword" className="labelLeft">Confirm Password: </label>
        </div>
        <div className="col-md-9">
        <input type="password" value={this.state.confirmPassword}
          onChange={this.handleChange}
          type="password" id="confirmPassword" className="inputLeft"/>
          </div>
          <div className="messageLeft">{this.state.confirmPasswordError}</div>
          </div>
          </div>
      </div>
      <br/>
      
     <div>
      <label>
       <input type="submit" value="Save" id="button" class="button1"/>
       </label>
      </div>  
</form>
  );
}
  render() {
    return (
      <div className="Signup">
       {this.renderForm()}
      </div>
  
    );
  }
}
