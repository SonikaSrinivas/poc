import React, { Component } from 'react';

import  createHistory from 'history/createBrowserHistory';
const history= createHistory();


class Register extends Component {

    constructor() {
        super();
        this.state = {
            username: '',
            password: '',
            email: '',
            confirmpassword: '',
            gender: '',
            mobileno:'',
            
            usernameError: '',
            passwordError: '',
            confirmpasswordError: '',
            emailError: '',
            genderError: '',
            mobilenoError:'',
            hobbiesError: ''
        }
    }

    onChanged = (event) => {
        this.setState({ [event.target.name]: event.target.value })
    }

    validate = () => {
        let isError = false;
        const errors = {
            usernameError: "",
            emailError: "",
            passwordError: "",
            confirmpasswordError: '',
            genderError: '',
            mobilenoError: ''
        };
        if (this.state.username.length < 5) {
            isError = true;
            errors.usernameError = "Username needs to be atleast 5 characters long";
        }
        if (this.state.username === '') {
            isError = true;
            errors.usernameError = "Username Required ";
        }

        if (this.state.email.indexOf("@") === -1) {
            isError = true;
            errors.emailError = "Requires valid email";
        }
        if (this.state.password === '') {
            isError = true;
            errors.passwordError = "Password Required ";
        }
        if (this.state.confirmpassword === '') {
            isError = true;
            errors.confirmpasswordError = "Confirm Password Required ";
        }
        if (this.state.gender === '') {
            isError = true;
            errors.genderError = "Gender Required ";
        }
        if (this.state.mobileno === '') {
            isError = true;
            errors.mobilenoError = "Mobile Number Required ";
        }
       
        this.setState({
            ...this.state,
            ...errors
        });

        return isError;
    };



    onSubmit = (event) => {
        event.preventDefault();
        console.log(this.state);
        const err = this.validate();
        if (!err) {
            // clear form
            this.setState({
                username: '',
                usernameError: '',
                password: '',
                passwordError: '',
                confirmpassword: '',
                confirmpasswordError: '',
                email: '',
                emailError: '',
                gender: '',
                genderError: '',
               
                mobileno: '',
                mobilenoError: ''
            });
            // this.props.onChange({
            //     username: "",
            //     email: "",
            //     password: "",
            //     confirmpassword: "",
            //     gender: "",
            //     hobbies: "",
            //     qualification: ""

            // });
            alert("Registered successfully")

            this.props.history.push('/login');
        }


    }

    render() {

        const { username, password, email, confirmpassword, gender, mobileno } = this.state;

        return (
            <div className="row">
            <div className="col-sm-offset-2 col-sm-8">
            <div className="well">
                <h2>Create a Account</h2>
                <hr/>
                <form onSubmit={this.onSubmit}>

                    <div className="form-group">
                        <label> User Name :</label>
                        <input name="username" onChange={this.onChanged}
                            value={username} type="text" className="form-control" />
                   <span style={{color: "red"}}>{this.state.usernameError}</span>
                    </div>

                    <div className="form-group">
                        <label> Password :</label>
                        <input name="password" onChange={this.onChanged}
                            value={password} type="password" className="form-control" />
                    <span style={{color: "red"}}>{this.state.passwordError}</span>
                    </div>

                    <div className="form-group">
                        <label> Confirm Password :</label>
                        <input name="confirmpassword" onChange={this.onChanged}
                            value={confirmpassword} type="password" className="form-control" />
                    <span style={{color: "red"}}>{this.state.confirmpasswordError}</span>
                    </div>

                    <div className="form-group">
                        <label> Email :</label>
                        <input name="email" onChange={this.onChanged}
                            value={email} type="text" className="form-control" />
                    <span style={{color: "red"}}>{this.state.emailError}</span>
                    </div>

                    <div className="form-group">
                        <label> Gender :</label>&nbsp; &nbsp;
                        <input name="gender" onChange={this.onChanged}
                            value={gender} type="radio"  value="Male" /> Male &nbsp; &nbsp;
                        <input name="gender" onChange={this.onChanged}
                            value={gender} type="radio"  value="Female" /> Female
                            <span style={{color: "red"}}>{this.state.genderError}</span>
                    </div>
                    <div className="form-group">
                        <label> Mobile Number :</label>
                        <input name="mobileno" onChange={this.onChanged}
                            value={mobileno} type="number" className="form-control" />
                    <span style={{color: "red"}}>{this.state.mobilenoError}</span>
                    </div>


                    <button className="btn btn-success" type="submit">Sign In</button>

                    <p>By creating an account, I accept the <a>Terms & Conditions</a></p>
                </form>
            </div>
            </div></div>
        )
    }
}

export default Register;


