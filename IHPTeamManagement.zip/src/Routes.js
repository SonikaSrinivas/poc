import React from "react";
import { Route, Switch } from "react-router-dom";
import Home from "./Home";
import NotFound from "./NotFound";
import Login from "./Login";
import AppliedRoute from "./components/AppliedRoute";
import Signup from "./Signup";
import Welcome from "./Welcome";
import ProjectInfo from "./ProjectInfo";
import TeamInfo from "./TeamInfo";
import EditTeamInfo from "./EditTeamInfo";
import SignUpSuccess from "./SignUpSuccess";
import CreateSkillProficiency from "./components/CreateSkillProficiency";
import ViewSkillProficiency from "./components/ViewSkillProficiency";
import SkillMatrix from "./components/SkillMatrix";
import EditSkillProficiency from "./components/EditSkillProficiency";
import shiftroaster from "./components/Shiftdropdown";
import lms from "./components/Dropdown";
import Gallery from "./components/Gallery";
import Ethnic from "./components/Ethnic";
import Christmas from "./components/Christmas";

export default ({ childProps }) =>
  <Switch>
    <AppliedRoute path="/" exact component={Home} props={childProps} />
    <AppliedRoute path="/login" exact component={Login} props={childProps} />
    <AppliedRoute path="/signup" exact component={Signup} props={childProps} />
    <AppliedRoute path="/welcome" exact component={Welcome} props={childProps} />
    <AppliedRoute path="/ProjectInfo" exact component={ProjectInfo} props={childProps} />
    <AppliedRoute path="/TeamInfo" exact component={TeamInfo} props={childProps} />
    <AppliedRoute path="/EditTeamInfo" exact component={EditTeamInfo} props={childProps} />
    <AppliedRoute path="/SignUpSuccess" exact component={SignUpSuccess} props={childProps} />
    <AppliedRoute path='/CreateSkillProficiency' exact component={CreateSkillProficiency} props={childProps}/>
    <AppliedRoute path='/ViewSkillProficiency' exact component={ViewSkillProficiency} props={childProps}/>
    <AppliedRoute path='/SkillMatrix' exact component={SkillMatrix} props={childProps}/>
    <AppliedRoute path='/EditSkillProficiency' exact component={EditSkillProficiency} props={childProps}/>
    <AppliedRoute path='/lms' exact component={lms} props={childProps}/>
    <AppliedRoute path='/shiftroaster' exact component={shiftroaster} props={childProps}/>
    <AppliedRoute path='/Gallery' exact component={Gallery} props={Gallery}/>
    <AppliedRoute path='/Ethnic' exact component={Ethnic} props={Ethnic}/>
   <AppliedRoute path='/Christmas' exact component={Christmas} props={Christmas}/>
    { /* Finally, catch all unmatched routes */ }
    <Route component={NotFound} />
  </Switch>;

