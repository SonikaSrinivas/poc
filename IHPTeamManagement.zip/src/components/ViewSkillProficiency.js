import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import ReactToExcel from "react-html-table-to-excel";

import '../table.css';

export default class ViewSkillProficiency extends Component {

  constructor(props, context) {
    super(props, context);
    this.state = {
      employees: [],
      planets: [],
      editEmpSkill: []


    };

  }

  componentDidMount() {

    fetch("http://localhost:5000/viewSkillproficiency")
      .then(res => res.json())
      .then(data => {
        this.setState({
          employees: data

        });

      })
      .catch(err => console.error);
  }


  editSkillprof =(id,skill_id) => event => {
    event.preventDefault();
    console.log("Fetching" + id);
    fetch("http://localhost:5000/editSkillproficiency/" + id+'/'+skill_id)
      .then(res => res.json())
      .then(data => {
        console.log("DATAAAA" + data[0]);
        this.props.history.push({
          pathname: "/EditSkillProficiency",
          state: {
            editEmpSkill: data[0]
 }


        });


      })
      .catch(err => console.error);
  }

  deleteSkillprof = (emppid,skillid) => event => {
    console.log("In Delete");
    fetch('http://localhost:5000/deleteskillprof/' +emppid+'/'+skillid, {
      method: 'DELETE',
    })
      .then(console.log('Deleted'))
      .catch(err => console.error); 
      fetch("http://localhost:5000/viewSkillproficiency")
      .then(res => res.json())
      .then(data => {
         this.setState({
          employees: data
          
      }); 
      this.props.history.push('/ViewSkillproficiency');
      })
      
      .catch(err => console.error); 
       
       
      } 


  render() {

    return (
      <div className="container">
        
                <h4 align="center"><u>Skill Details</u></h4>
                
        <table className="table table-striped" id="table-to-xls" table border="1" >
          <thead>
            <tr class="tabletemplate">
              <th> Name</th>
              <th>Skills</th>
              <th>Proficiency</th>
              <th>Last Used</th>
              <th>Exp(Months)</th>
              <th></th>
              <th></th>
            </tr>
          </thead>


          <tbody>
            {/*  {this.tabRow()} */}
            {this.state.employees.map(row => (
              <tr key={row.id}>
                <td>{row.emp_name}</td>
                <td>{row.skill}</td>
                <td>{row.proficiency}</td>
                <td>{row.last_used}</td>
                <td>{row.experience}</td>
                {((sessionStorage.getItem("userName")) === row.emp_name || (sessionStorage.getItem("userRole") === "Admin"))
                  ? <td>
                    <Link to={'/editSkillproficiency/:' + row.cg_emp_id} className="btn btn-primary" onClick={this.editSkillprof(row.cg_emp_id,row.skill_id)}>Edit</Link>
                  </td>
                :<td>Edit</td>
                }
               {((sessionStorage.getItem("userName")) === row.emp_name || (sessionStorage.getItem("userRole") === "Admin"))
                  ? <td>
                    <button onClick={this.deleteSkillprof(row.cg_emp_id,row.skill_id)} className="btn btn-danger" >Delete</button>
                  </td>
                  :<td>Delete</td>
                }
              </tr>
            ))}
          </tbody>
        </table>
        <ReactToExcel
          className="btn"
          table="table-to-xls"
          filename="SkillProficiencyInfo"
          sheet="sheet 1"
          buttonText="Export"
        />
      </div>
    )
  }
}