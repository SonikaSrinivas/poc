import React, { Component } from 'react';
import Home from '../pages/Home';
import  createHistory from 'history/createBrowserHistory';
import axios from 'axios';
const history= createHistory();


class AddEvent extends Component {

    constructor() {
        super();
        this.serviceUrl = "http://localhost:5000/api/event";
        this.state = {
            post:[{
          
            eventname: "",
            start: "",
            end:"",
            image:"",
            location:"",
            adultprice:"",
            childprice:"",
            food:["",""],
            drinks:"",
            description: ""
        }]
    }
}
    
    onChanged = (event) => {
        this.setState({ [event.target.name]: event.target.value })
    }
    onSubmit=(event)=>{
        event.preventDefault();
        console.log(this.state);
        alert("posted");
        this.props.history.push('/home');
        window.location.reload(); 

        let newPost=[...this.state.post];
            let newpost={
                eventname:this.state.eventname,
                start:this.state.start,
                end:this.state.end, 
                image:this.state.image, 
                location:this.state.location, 
                adultprice:this.state.adultprice, 
                childprice:this.state.childprice, 
                food:this.state.food, 
                drinks:this.state.drinks, 
                description:this.state.description
            }
            axios.post(this.serviceUrl,newpost).then((res)=>{
                newPost.push(newpost);
                this.setState({post:newPost});
            })
    }
       componentDidMount() {
          let _id = this.props.match.params._id;
          axios.get(this.serviceUrl + _id).then((res) => {
             this.setState({
                event: res.data
             })
          })
        }
    
    render() {

        const {  eventname, start, end, image, location, adultprice, childprice, food, drinks, description} = this.state;

        return (
            <div className="row">
            <div className="col-sm-offset-2 col-sm-8">
            <div className="well">
                <h2>Create a Event</h2> <hr/>
                <form onSubmit={this.onSubmit}>

                    <div className="form-group">
                        <label> Event Name :</label>
                        <input name="eventname" onChange={this.onChanged}
                            value={eventname} type="text" className="form-control"  placeholder="Enter the Event Name" required/>                   
                    </div>

                    <div className="form-group">
                        <label> start Date/Time :</label>
                        <input name="start" onChange={this.onChanged}
                            value={start} type="date" className="form-control"  placeholder="Enter Start date of Event" required/>
                    </div>

                    <div className="form-group">
                        <label> End Date/Time :</label>
                        <input name="end" onChange={this.onChanged}
                            value={end} type="date" className="form-control"  placeholder="Enter End date of Event" required/>
                    </div>
                    <div className="form-group">
                        <label> image:</label>
                        <image images="images" onChange={this.onChanged}
                            value={image} className="form-control" type="file" />
                    </div>


                    <div className="form-group">
                        <label> Location :</label>
                        <input name="location" onChange={this.onChanged}
                            value={location} type="text" className="form-control"  placeholder="Enter location" required/>
                    </div>
                    
                    <div className="form-group">    
                        <label> Adult Price :</label>
                        <input name="adultprice" onChange={this.onChanged}
                            value={adultprice} type="number" className="form-control"  placeholder="Enter price for adult" required/>
                    </div>
                    <div className="form-group">
                        <label> Child Price :</label>
                        <input name="childprice" onChange={this.onChanged}
                            value={childprice} type="number" className="form-control" placeholder="Enter price for child" />
                    </div>
    
                    <div className="form-group">
                        <label> Food options :</label>&nbsp; &nbsp;
                        <input name="food" onChange={this.onChanged}
                            value={food} type="checkbox"  value="veg" /> Veg &nbsp; &nbsp;
                        <input name="food" onChange={this.onChanged}
                            value={food} type="checkbox"  value="nonveg" /> Non-Veg &nbsp; &nbsp;
                        <input name="food" onChange={this.onChanged}
                            value={food} type="checkbox"  value="notapplicable" /> Not Applicable &nbsp; &nbsp;
                            <span style={{color: "red"}}>{this.state.foodError}</span>
                    </div>
                    <div className="form-group">
                        <label> Drinks :</label>&nbsp; &nbsp;
                        <input name="drinks" onChange={this.onChanged}
                            value={drinks} type="radio"  value="Applicable" /> Applicable &nbsp; &nbsp;
                        <input name="drinks" onChange={this.onChanged}
                            value={drinks} type="radio"  value="Not Applicable" /> Not Applicable
                            <span style={{color: "red"}}>{this.state.drinksError}</span>
                    </div>

                    <div className="form-group">
                        <label> Description :</label>
                        <input name="description" onChange={this.onChanged}
                            value={description} type="text" className="form-control" placeholder="Enter Description about the Event" required/>
                    </div>


                    <button className="btn btn-primary" type="submit">Submit</button>

                   
                </form>
            </div>
           
            </div></div>
        )
    }
}

export default AddEvent;


