import React from 'react';
import {Link} from 'react-router-dom' ;  

import {
HelpBlock,
FormGroup,
FormControl,
ControlLabel
} from "react-bootstrap"; 

class Shiftdropdown extends React.Component {
  
constructor(props){
  super(props);
    this.state={
        employees: [],
        employeeId:"",
        planets: [],
        empname:""
    };
    this.onChangeCGempId = this.onChangeCGempId.bind(this);
  }
  
  
  
  onChangeCGempId(e) {
    var index = e.target.selectedIndex;
    this.setState({

        cg_emp_id: e.target.childNodes[index].getAttribute('data-id')
    });


}
    componentDidMount()
    {
        this.getEmployees();
        fetch("http://localhost:5000/getEmployeeName")
        .then(res => res.json())
        .then(data => {
            this.setState({
                planets: data

            });
            console.log(data.recordset[0]);
        })
        .catch(err => console.error);

    fetch("http://localhost:5000/skillslist")
        .then(res => res.json())
        .then(data => {
            this.setState({
                skills: data

            });
            console.log(data.recordset[0]);
        })
        .catch(err => console.error);
    }
  getEmployees=_=>{
      fetch('http://localhost:5000/teamroaster')
      .then(response => response.json())
      .then(data => {
          this.setState({
            employees: data
            });   
           // console.log(data);
      })
.catch(err =>  console.error(err))
    }
    handleChange = event => {
      this.setState({
      [event.target.id]: event.target.value
      });
      } 

    handleSubmit = event => {
      event.preventDefault();
      console.log("hi Lead");
      fetch('http://localhost:5000/teamroaster',
  {
  method: 'POST',
  headers: {
  Accept: 'application/json',
  'Content-Type': 'application/json'
  },
  body: JSON.stringify({
  //"CG_EMP_ID":parseInt(this.state.employeeId), 
 // "EMP_NAME":this.state.empname, 
  //"START_DATE":"2017-04-03 00:00:00", 
 // "END_DATE":"2017-05-03 00:00:00", 
  
  "CG_EMP_ID":parseInt(this.state.employeeId),
  "Emp_NAME":this.state.empname,
  "Start_Date":"2017-04-03",
  "End_Date":"2018-04-03",
  "PRIM_OR_SEC":"y",
  })
  }).then(res => res.json())
  .then(resData => {
  console.log(resData);
  // this.fetchOrders();
  })
  .catch(err => console.error);
  }
  

    renderEmployees =({name})=><div key={name}></div>
    render()
    {


      let emps = this.state.planets;
      //console.log(emps);
      let optionItems_employee = emps.map((planet) =>
          <option value={planet.EMP_NAME} data-id={planet.CG_EMP_ID} key={planet.CG_EMP_ID}>{planet.EMP_NAME}</option>

      );



        const { employees} = this.state;
        return(
            <div><center>
              <a href='http://localhost:3000/'>Home</a>
                <h1><center>Shift Roaster Application</center></h1>
              <form onSubmit={this.handleSubmit}>

              {/* <FormGroup controlId="employeeId" bsSize="large">
<ControlLabel>Employee ID</ControlLabel>
<FormControl
value={this.state.employeeId}
onChange={this.handleChange}
type="number"
/> 
</FormGroup> */}
{/* <FormGroup controlId="empname" bsSize="large">
<ControlLabel>Employee Name</ControlLabel>
<FormControl
value={this.state.empname}
onChange={this.handleChange}
type="string"
/> 
</FormGroup> */}

<label htmlFor="name"><b>Employee Name</b></label>
<select value={this.state.value} onChange={this.onChangeCGempId} className="new-control">
                            {optionItems_employee}
                        </select>
                
              {/* <label htmlFor="name"><b>Employee ID:</b></label>
              <input type='text'/>
              <nbsp></nbsp> <label htmlFor="name"><b>Employee Name:</b> </label>
                <input
                  id="name"
                  type="text"
                  value={this.state.name}
                  onChange={this.handleChange}
                /> */}
                {/* <label htmlFor="shiftraoster">Month of ShiftRoaster </label>
                <input
                  id="shiftraoster"
                  type="text"
                  value={this.state.shiftraoster}
                  onChange={this.handleChange}

                /> */}
                {/* <label htmlFor="name"><b>Month:</b></label>
                <select>
                <option value="Month">Select Month</option>
                <option value="Jan">Jan</option>
                <option value="Feb">Feb</option>
                <option value="Mar">Mar</option>
                <option value="Apr">Apr</option>
                <option value="May">May</option>
                <option value="Jun">Jun</option>
                <option value="Jul">Jul</option>
                <option value="Aug">Aug</option>
                <option value="Sep">Sep</option>
                <option value="Oct">Oct</option>
                <option value="Nov">Nov</option>
                <option value="Dec">Dec</option>

            </select> */}
            <label htmlFor="name"><b>Oncall Type:</b></label>
            <select>
                <option value="P">Primary</option>
                <option value="S">Secondary</option>
                </select>
                <b>Start Date:</b> <input type="date" name="bday" value={this.state.staetdate}></input>
                <br></br>
                <b>End Date:</b> <input type="date" name="bday" value={this.state.endtdate}></input>
                <br></br>
                <br></br>
                <button type="submit">Submit</button>
              </form>
            {/* {employees.map(this.renderEmployees)} */}
            <br></br>
            <table border="1"><center></center>
<tr>
<th>EMP NAME</th>
<th>Oncall Start Date</th>
<th>Oncall End Date</th>
<th>Primary or Secondary</th>
</tr>
{this.state.employees.map(row => (
<tr key={row.EMP_NAME}>
<td>{row.EMP_NAME}</td>
<td>{row.START_DATE}</td>
<td>{row.END_DATE}</td>
<td><center>{row.PRIM_OR_SEC}</center></td>
<td><button  className="btn btn-primary">Edit</button></td>
          <td><button  className="btn btn-danger">Delete</button></td>
</tr>
))}
</table> 
           
</center> </div>
        )
    }

}
export default Shiftdropdown;
