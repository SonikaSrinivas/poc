const mongoose =require("mongoose");

const eventregistrationSchema =mongoose.Schema({
    fullname:{
        type:String,
        required:true
    },
    email:{
        type:String,
        required:true
    },
    mobileno:{
        type:Number,
        required:true
    },
    headcountadult:{
        type:Number,
        required:true
    },
    headcountchild:{
        type:Number
        
    },
    headcountbaby:{
        type:Number
        
    },
    eventtype:{
        type:String
       
    },
    food:{
        type:String
        
    },
    drinks:{
        type:String
        
    }
})
const EventReg= module.exports= mongoose.model('EventReg', eventregistrationSchema);