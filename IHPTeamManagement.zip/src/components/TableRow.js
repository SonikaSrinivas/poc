import React, { Component } from 'react';
import { Link } from 'react-router-dom';

//import axios from 'axios';

class TableRow extends Component {

  constructor(props) {
    super(props);
    this.deleteskillprof = this.deleteskillprof.bind(this);
}
deleteskillprof() {
    console.log(this.props.obj.CG_EMP_ID);
    fetch('http://localhost:5000/deleteskillprof/'+this.props.obj.CG_EMP_ID,{
    method: 'DELETE',
})
        .then(console.log('Deleted'))
        .catch(err => console.log(err)) 
        alert("Record deleted successfully");
        window.location.reload();
}


  render() {
     
  return (
        <tr>
          <td>
            {this.props.obj.CG_EMP_ID}
          </td>
          <td>
            {this.props.obj.SKILL_ID}
          </td>
          <td>
            {this.props.obj.PROFICIENCY}
          </td>
          <td>
            {this.props.obj.LAST_USED}
          </td>
          <td>
            {this.props.obj.EXPERIENCE}
          </td>
          <td>
          <Link to={"/EditSkillProficiency/"+this.props.obj.SKILL_ID} className="btn btn-primary">Edit</Link>
          </td>
          <td>
            <button onClick={this.deleteskillprof} className="btn btn-danger" >Delete</button>
          </td>
        </tr>
    );
  }
}

export default TableRow;