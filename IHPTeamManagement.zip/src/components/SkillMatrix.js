import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import ReactToExcel from "react-html-table-to-excel";
import "../matrix.css";

export default class SkillMatrix extends Component {

  constructor(props, context) {
    super(props, context);
    this.state = {
      employees: [],
      planets: [],
      editEmpSkill: [],
      skill_id:'',
      skills:[],
      

    };

  }

  componentDidMount() {

    fetch("http://localhost:5000/viewSkillproficiency")
      .then(res => res.json())
      .then(data => {
        this.setState({
          employees: data

        });

      })
      .catch(err => console.error);

      fetch("http://localhost:5000/skillslist")
      .then(res => res.json())
      .then(data => {
          this.setState({
              skills: data

          });
          console.log(data.recordset[0]);
      })
      .catch(err => console.error);

      
  }



  render() {
    
    let skills = [];
   
    let skill = this.state.skills;
    // console.log(skill);
    let optionItems_skills = skill.map((empskill) =>
        <option value={empskill.SKILL} skill-id={empskill.SKILL_ID} key={empskill.SKILL_ID}>{empskill.SKILL}</option>   
 );
  
 

   
    return (
      <div className="container">
        <h4 align="left"><u>Skill Matrix</u></h4>
        <table id="table-to-xls" table border="3" >
          <thead>  
            
            <tr bgcolor="#85C1E9" height='80'>
              
              <th> </th>
              {optionItems_skills.map(row=>(
            
             <th width='60'><div className="verticalTableHeader">{row}</div></th>
        

        ))}
        
        </tr>
       
          </thead>
           <tbody>
       
       {this.state.employees.map(row =>(
           
            <tr key ={row.id}>
           <td width='150' className="firstcolumn">{row.emp_name}</td> 
           {this.state.skills.map(row1=>( 
            (row.skill_id===row1.SKILL_ID && row.proficiency==='Expert')?
             <td align="center" bgcolor="orange">E</td>:
             (row.skill_id===row1.SKILL_ID && row.proficiency==='Good')?
            <td  bgcolor="yellow">G</td>:
            (row.skill_id===row1.SKILL_ID && row.proficiency==='Moderate')?
            <td  bgcolor="#5499C7">M</td>:
            (row.skill_id===row1.SKILL_ID && row.proficiency==='Beginner')?
            <td  bgcolor="#52BE80" text-color="white">B</td>:
            (row.skill_id===row1.SKILL_ID && row.proficiency==='No knowledge')?
            <td  bgcolor="#E5E8E8">N</td>:
            (row.skill_id===row1.SKILL_ID && row.proficiency==='Attended Basic Training')?
            <td  bgcolor="lightgreen">T</td>:<td bgcolor="#E5E8E8">N</td>
            
   ))} 
      
   
   </tr>
    
  
 

))}
        
      </tbody>
     
      </table>
      <table>
        <tr></tr>
      </table>
      <br/>
        <ReactToExcel
          className="btn"
          table="table-to-xls"
          filename="SkillProficiencyInfo"
          sheet="sheet 1"
          buttonText="Export"
        />
     
        <table  border="1" align="right" className="">
        <caption><th>Legand</th></caption>
       <tr><td bgcolor="#E5E8E8">N</td><td>No knowledge</td></tr>
       <tr><td  bgcolor="#52BE80">B</td><td>Beginner</td></tr>
       <tr><td bgcolor="#5499C7">M</td><td>Moderate</td></tr>
       <tr><td bgcolor="yellow">G</td><td>Good</td></tr>
       <tr><td bgcolor="orange">E</td><td>Expert</td></tr>
      <tr><td bgcolor="lightgreen">T</td><td>Attended Basic Training</td> </tr> 
       </table>
       
      </div>
      
     
    )
 
            
   
  
  }
}