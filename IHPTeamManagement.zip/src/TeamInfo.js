
import React, { Component } from "react";
import ReactToExcel from "react-html-table-to-excel";
//import  ActionCells from '/.ActionCells.js';

import './table.css';

class TeamInfo extends Component
 {
  constructor(props, context) {
    super(props, context);
    this.state = {
        teaminfo: [],
        response:{}
        };
   
}
displayTeamInfolist(){
  fetch("http://localhost:5000/teaminfo")
  .then(res => res.json())
  .then(data => {
    this.setState({
      teaminfo: data
      
  }); 
      //console.log(data.recordset[0]);
  })
  .catch(err => console.error);
}

componentDidMount(){
  this.displayTeamInfolist();
}

  

  /*fetchData = event => {
    event.preventDefault();
    console.log("Fetching");
    fetch("http://localhost:5000/teaminfo")
            .then(res => res.json())
            .then(data => {
               this.setState({
                teaminfo: data
                
            }); 
              //console.log(data.recordset[0]);
            })
            .catch(err => console.error);
  }  */ 
  editUser=id=>event=>{
    event.preventDefault();
    console.log("Fetching"+id);
    fetch("http://localhost:5000/employees/"+id)
            .then(res => res.json())
            .then(data => {
                
              //console.log(data.recordset[0]);
              this.props.history.push({pathname:"/EditTeamInfo",
              state: {
                teamInfoKey:data[0]
                
               }
              });
            })
            .catch(err => console.error);
    //this.props.history.push("/EditTeamInfo");
    
  }
  deleteUser=id=>event=>{
    event.preventDefault();
    const {teaminfo}=this.state;
    
    alert("Fetching"+id);
    fetch('http://localhost:5000/employeeDelete',
    {
    method: 'PUT',
    headers: {
    Accept: 'application/json',
    'Content-Type': 'application/json'
    },
    body: JSON.stringify({
    "CG_EMP_ID":parseInt(id), 
    "delete_flag":"D",
    })
    }).then(res => res.json())
    .then(resData => {
      this.setState({
        response: resData,
        teaminfo:teaminfo.filter(row=>row.CG_EMP_ID!==id)
    }); 
    
    })
    .catch(err => console.error); 
    //this.displayTeamInfolist();
    fetch("http://localhost:5000/teaminfo")
  .then(res => res.json())
  .then(data => {
    this.setState({
      teaminfo: data
      
  }); 
      //console.log(data.recordset[0]);
      this.props.history.push('/TeamInfo'); 
  })
  .catch(err => console.error);
      
    
    
  }
 
  render(){
      console.log(this.state.teaminfo);
    return (
    <div className="container" align="center">
           <h4 align="center"><u>Team Information</u></h4>
  
    <table class="table table-striped" id="table-to-xls"  table border="1" align="center">
     
    <tr class="tabletemplate">
          <th>Emp ID</th>
          <th>Name</th>
          <th>CG ID</th>
          <th>CG Email ID</th>
          <th>IKEAID</th>
          <th>IKEA MailID</th>
          <th> Band </th>
          <th>Pr Code</th>
          <th>Pr Role</th>
          <th>Start Date</th>
          <th>End Date</th>
          <th>Role</th>
          <th></th>
          <th></th>
        
      </tr>
     
      <tbody>
      {this.state.teaminfo.map(row => (
        <tr key={row.CG_EMP_ID}>
          
	        <td>{row.CG_EMP_ID}</td>
          <td>{row.EMP_NAME}</td>
          <td>{row.CG_USER_ID}</td>
          <td>{row.CG_EMAILID}</td>
          <td>{row.IKEA_USER_ID}</td>
          <td>{row.IKEA_MAILID}</td>
          <td>{row.BAND}</td>
          <td>{row.PROJECT_CD}</td>
          <td>{row.PROJ_ROLE}</td>
          <td>{row.START_DATE.slice(0,-14)}</td>
          <td>{row.END_DATE.slice(0,-14)}</td>
          <td>{row.ROLE}</td>
          {((sessionStorage.getItem("userName"))===row.EMP_NAME || (sessionStorage.getItem("userRole")==="Admin"))
        ?<td><button onClick={this.editUser(row.CG_EMP_ID)} className="btn btn-primary">Edit</button></td>
        :<td>Edit</td>
      }
       {((sessionStorage.getItem("userRole")==="Admin"))      
          ?<td><button onClick={this.deleteUser(row.CG_EMP_ID)} className="btn btn-danger">Delete</button></td>
          :<td>Delete</td>
    }


        </tr>
      ))}
      </tbody>
      </table>
      <br/>
        <ReactToExcel 
        className="btn"
        table="table-to-xls"
        filename="TeamInfo"
        sheet="sheet 1"
        buttonText="Export"
        />
    </div>
  );

}

 }
 export default TeamInfo;