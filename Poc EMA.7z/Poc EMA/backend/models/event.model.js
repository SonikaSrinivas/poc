const mongoose =require("mongoose");

const eventSchema =mongoose.Schema({
    eventname:{
        type:String
    },
    start:{
        type:Date
    },
    end:{
        type:Date
    },
    image:{
        type:String
    },
    location:{
        type:String
    },
    adultprice:{
        type:Number
        
    },
    childprice:{
        type:Number
    },
    food:[{ type:String, type:String

    }],
      
    drinks:{
        type:String
       
    },
    description:{
        type:String
        
    }
})
const event= module.exports= mongoose.model('event', eventSchema);