
const mssql=require('mssql');
const express=require('express');
var app=express();
const bodeyparser=require('body-parser');
var cors=require('cors');
app.use(cors());
app.use(bodeyparser.json());
session = require('express-session');
app.use(session({
    secret: '2C44-4D44-WppQ38S',
    resave: true,
    saveUninitialized: true
}));

var sqlserverconnection=new mssql.ConnectionPool(
    {
    user: "FOOD_PLANNER_APP",
    password: "f00dp1ann3rapp",
    server: "PTPSEELM-NT2008.ikeadt.com",
    database: "IHP_MYTEAM",
    multipleStatements:true,
    
    options: {
      encrypt: true
    }
    }
);
sqlserverconnection.connect(
    (err)=>{
        if(!err)
        console.log('DB connection succeded');
        else
        console.log('DB connection failed \n error:'+JSON.stringify(err,undefined,2));
    });
   app.listen(5000,()=>console.log('Express server running at port number 5000'));

   //Get all employees
/* app.get('/employees',(req,res)=>{
    sqlserverconnection.query('SELECT * FROM employees',(err,rows,fields)=>{
        if(!err)
        res.send(rows.recordset);
        else
        res.send(err);
    })
}); */

app.get('/teaminfo',(req,res)=>{
    sqlserverconnection.query("SELECT * FROM TEAM_INFO where delete_flag='E'",(err,rows,fields)=>{
        if(!err)
        res.send(rows.recordset);
        else
        res.send(err);
    })
});

app.get('/projectinfo',(req,res)=>{
    sqlserverconnection.query('SELECT * FROM PROJECT_INFO',(err,rows,fields)=>{
        if(!err)
        res.send(rows.recordset);
        else
        res.send(err);
    })
});


//Get a particular employee having given name
app.get('/employees/:id',(req,res)=>{
    sqlserverconnection.query('SELECT * FROM TEAM_INFO where CG_EMP_ID='+req.params.id,(err,rows,fields)=>{
        if(!err)
        res.send(rows.recordset);
        else
        res.send(err);
    })
});




// Authentication and Authorization Middleware
var auth = function(req, res, next) {
    if (req.session && req.session.user && req.session.password)
      return next();
    else
      return res.sendStatus(401);
  };

//Get a particular employee having username and password
app.get('/employee/:email/:pass',(req,res)=>{
    //let employee=req.body;
    //sqlserverconnection.query('SELECT * FROM employees where first_name='+"'"+employee.firstname+"'"+'and last_name='+"'"+employee.lastname+"'",(err,rows,fields)=>{
        sqlserverconnection.query('SELECT * FROM TEAM_INFO where cg_emailid='+"'"+req.params.email+"'"+'and password='+"'"+req.params.pass+"'"+"and delete_flag='E'",(err,rows,fields)=>{
        if(!err)
        {
        req.session.user = rows.recordset.CG_EMAILID;
        req.session.password = rows.recordset.password;
        res.send(rows.recordset);
        }
        //console.log("result"+rows.recordset);
        else
        //res.send(err);
        console.log("error"+err);
    })
});

// Logout endpoint
app.get('/logout', function (req, res) {
    req.session.destroy();
    res.send("logout success!");
    }); 


//Delete an employee
app.delete('/employees/:id',(req,res)=>{
    sqlserverconnection.query('delete from employees where employee_id='+req.params.name,(err,rows,fields)=>{
        if(!err)
        res.send("Deleted successfully");
        else
        res.send(err);
    })
});


/* //Insert an user
app.post('/employees',(req,res)=>{
    let employee=req.body;
    console.log(employee);
    
    sqlserverconnection.query("insert into employees values("+employee.id+','+"'"+employee.lastname+"'"+','+"'"+employee.firstname+"'"+','+employee.salary+");",(err,rows,fields)=>{
        //sqlserverconnection.query(sql,parameters,(err,rows,fields)=>{
        if(!err)
       res.send(rows.count);
        else
        res.send(err);
    })
}); */
//Insert an user
app.post('/employees',(req,res)=>{
    let TEAM_INFO=req.body;
    console.log(TEAM_INFO);
    sqlserverconnection.query("insert into TEAM_INFO values("+TEAM_INFO.CG_EMP_ID+','+"'"+TEAM_INFO.EMP_NAME+"'"+','+"'"+TEAM_INFO.CG_USER_ID+"'"+','+"'"+TEAM_INFO.CG_EMAILID+"'"+','+"'"+TEAM_INFO.IKEA_USER_ID+"'"+','+"'"+TEAM_INFO.IKEA_MAILID+"'"+','+"'"+TEAM_INFO.BAND+"'"+','+TEAM_INFO.PROJECT_CD+','+"'"+TEAM_INFO.PROJ_ROLE+"'"+','+"'"+TEAM_INFO.START_DATE+"'"+','+"'"+TEAM_INFO.END_DATE+"'"+','+"'"+TEAM_INFO.ROLE+"'"+','+"'"+TEAM_INFO.password+"'"+','+"'"+TEAM_INFO.delete_flag+"'"+ ");",(err,rows,fields)=>{
    //sqlserverconnection.query(sql,parameters,(err,rows,fields)=>{
    if(!err)
    res.send(rows.count);
    else
    res.send(err);
    })
    });  
    //Update an employee   
    app.put('/employees',(req,res)=>{
        let TEAM_INFO=req.body;
        console.log(TEAM_INFO);
        sqlserverconnection.query('update TEAM_INFO set EMP_NAME='+"'"+TEAM_INFO.EMP_NAME+"'"+','+"CG_USER_ID="+"'"+TEAM_INFO.CG_USER_ID+"'"+','+"CG_EMAILID="+"'"+TEAM_INFO.CG_EMAILID+"'"+','+"IKEA_USER_ID="+"'"+TEAM_INFO.IKEA_USER_ID+"'"+','+"IKEA_MAILID="+"'"+TEAM_INFO.IKEA_MAILID+"'"+','+"BAND="+"'"+TEAM_INFO.BAND+"'"+','+"PROJECT_CD="+TEAM_INFO.PROJECT_CD+','+"PROJ_ROLE="+"'"+TEAM_INFO.PROJ_ROLE+"'"+','+"START_DATE="+"'"+TEAM_INFO.START_DATE+"'"+','+"END_DATE="+"'"+TEAM_INFO.END_DATE+"'"+','+"ROLE="+"'"+TEAM_INFO.ROLE+"'"+','+"password="+"'"+TEAM_INFO.password+"'"+','+"delete_flag="+"'"+TEAM_INFO.delete_flag+"'"+" where CG_EMP_ID="+TEAM_INFO.CG_EMP_ID+";",(err,rows,fields)=>{
        if(!err)
        res.send(rows.recordset);
        else
        res.send(err);
        })
        });

   //Employee Soft delete
app.put('/employeeDelete',(req,res)=>{
    let TEAM_INFO=req.body;
    console.log(TEAM_INFO);
    sqlserverconnection.query('update TEAM_INFO set delete_flag='+"'"+TEAM_INFO.delete_flag+"'"+" where CG_EMP_ID="+TEAM_INFO.CG_EMP_ID+";",(err,rows,fields)=>{
if(!err)
    res.send(rows.recordset);
    else
    res.send(err);
    })
    });     
/*
//Update an user
app.put('/employees',(req,res)=>{
    let user=req.body;
    var sql="set @id=?;set @firstname=?;set @surname=?;\
    call userUpdate(@id,@firstname,@surname);";
    sqlserverconnection.query(sql,[user.id,user.firstname,user.surname],(err,rows,fields)=>{
        if(!err)
         res.send();
         else
         res.send(err);
    })
}); */

//Anup's service
  //rest api to create a new record into SKILLS table
  app.post('/create', function (req, res) {
    var sql = "INSERT INTO skills VALUES ('"+req.body.skill+"','"+req.body.version+"')";
    sqlserverconnection.query(sql, function (error, results, fields) {
       if (error) throw error;
       res.end(JSON.stringify(results));
       console.log("Data inserted");

     });
 });

 //rest api to create a new record into SKILL_PROFICIENCY table
 app.post('/createSkillproficiency', function (req, res) {
    //var sql = "INSERT INTO skill_proficiency VALUES ("+req.body.cg_emp_id+','+req.body.skill_id+','+"'"+req.body.proficiency+"'"+','+"'"+req.body.last_used+"'"+','+req.body.experience+")";
    sqlserverconnection.query("INSERT INTO skill_proficiency VALUES ("+req.body.cg_emp_id+','+req.body.skill_id+','+"'"+req.body.proficiency+"'"+','+"'"+req.body.last_used+"'"+','+req.body.experience+");", function (error, results, fields) {
      //  sqlserverconnection.query("INSERT INTO skill_proficiency VALUES (12789,1,'B','2',1)", function (error, results, fields) {  
    if (error) throw error;
       res.end(JSON.stringify(results));
       console.log("Data inserted");

     });

     sqlserverconnection.query("INSERT INTO skill_proficiency VALUES ("+req.body.cg_emp_id1+','+req.body.skill_id1+','+"'"+req.body.proficiency1+"'"+','+"'"+req.body.last_used1+"'"+','+req.body.experience1+");", function (error, results, fields) {
        //  sqlserverconnection.query("INSERT INTO skill_proficiency VALUES (12789,1,'B','2',1)", function (error, results, fields) {  
      if (error) throw error;
         res.end(JSON.stringify(results));
         console.log("Data inserted");
  
       });

       sqlserverconnection.query("INSERT INTO skill_proficiency VALUES ("+req.body.cg_emp_id2+','+req.body.skill_id2+','+"'"+req.body.proficiency2+"'"+','+"'"+req.body.last_used2+"'"+','+req.body.experience2+");", function (error, results, fields) {
        //  sqlserverconnection.query("INSERT INTO skill_proficiency VALUES (12789,1,'B','2',1)", function (error, results, fields) {  
      if (error) throw error;
         res.end(JSON.stringify(results));
         console.log("Data inserted");
  
       });
 });


  //Get all Skill Proficiency
  app.get('/viewSkillproficiency',(req,res)=>{
    sqlserverconnection.query('SELECT team_info.emp_name, s.cg_emp_id,s.skill_id, s.skill, s.proficiency, s.last_used, s.experience FROM (select sp.cg_emp_id, s.skill_id, s.skill, sp.proficiency, sp.last_used, sp.experience from skill_proficiency sp right outer join  skills s on s.skill_id = sp.skill_id) s, team_info WHERE team_info.cg_emp_id=s.cg_emp_id order by 1 ',(err,rows,fields)=>{
        //console.log("from Skill_proficiency table");
        if(!err)
        res.send(rows.recordset);
        else
        res.send(err);
    })
});

app.get('/editSkillproficiency/:cg_emp_id/:skill_id', (req, res) => {
    sqlserverconnection.query('with teamskils as(SELECT team_info.emp_name, s.cg_emp_id,s.skill_id, s.skill, s.proficiency, s.last_used, s.experience FROM (select sp.cg_emp_id, s.skill_id, s.skill, sp.proficiency, sp.last_used, sp.experience from skill_proficiency sp, skills s where s.skill_id = sp.skill_id) s, team_info WHERE team_info.cg_emp_id=s.cg_emp_id)select * from teamskils where CG_EMP_ID='+ req.params.cg_emp_id+'and SKILL_ID='+req.params.skill_id ,(err, rows, fields)=>{
   //console.log("from Skill_proficiency table" + req.params.cg_emp_id);
   if (!err) { 
   // console.log(rows.recordset); 
   res.send(rows.recordset); 
   } 
   else{
   console.log("in Error");
   res.send(err);
   }
   })
   }); 


   app.put('/editupdate',(req,res)=>
   {
   let SKILL_PROFICIENCY=req.body;
   console.log(SKILL_PROFICIENCY);
   sqlserverconnection.query('update SKILL_PROFICIENCY set SKILL_ID='+"'"+SKILL_PROFICIENCY.SKILL_ID+"'"+','+"PROFICIENCY="+"'"+SKILL_PROFICIENCY.PROFICIENCY+"'"+','+"LAST_USED="+"'"+SKILL_PROFICIENCY.LAST_USED+"'"+','+"EXPERIENCE="+"'"+SKILL_PROFICIENCY.EXPERIENCE+"'"+"where CG_EMP_ID="+SKILL_PROFICIENCY.CG_EMP_ID+"and SKILL_ID="+SKILL_PROFICIENCY.SKILL_ID+";",(err,rows,fields)=>{
    if(!err)
    {  
     res.send(rows.recordset);
    }
    else
    {
     res.send(err);
     console.log("record updated in error");
    }
    })
    });



  //Get all Employee Name
  app.get('/getEmployeeName',(req,res)=>{
    sqlserverconnection.query('SELECT * FROM team_info',(err,rows,fields)=>{
        //console.log("from Skill_proficiency table");
        if(!err)
        res.send(rows.recordset);
        
        else
        res.send(err);
    })
});

    //Get all Skills
app.get('/skillslist',(req,res)=>{
    sqlserverconnection.query('SELECT * FROM skills',(err,rows,fields)=>{
        if(!err)
        res.send(rows.recordset);
        else
        res.send(err);
    })
});


//Delete a Skill Profificiency
app.delete('/deleteskillprof/:id/:skillid',(req,res)=>{
    sqlserverconnection.query('delete from skill_proficiency where cg_emp_id='+req.params.id+"and SKILL_ID="+req.params.skillid,(err,rows,fields)=>{
        console.log("from Skill_proficiency table");
        if(!err)
        res.send("Deleted successfully");
        //console.log("from Skill_proficiency table");
        else
        res.send(err);
    })
});


//Delete a Skill 
app.delete('/deleteskill/:id',(req,res)=>{
    sqlserverconnection.query('delete from skills where skill_id='+req.params.id,(err,rows,fields)=>{
        console.log("from skills table");
        if(!err)
        res.send("Deleted successfully");
        //console.log("from Skill_proficiency table");
        else



        res.send(err);
    })
});

//Edit a Skill 
app.get('/editskill/:id',(req,res)=>{
    sqlserverconnection.query('select from skills where skill_id='+req.params.id,(err,rows,fields)=>{
        console.log("from skills table");
        if(!err)
        res.send("Edited successfully");
        //console.log("from Skill_proficiency table");
        else
        res.send(err);
    })
});

//Bala's code
app.get('/teamroaster',(req,res)=>{
    sqlserverconnection.query("SELECT EMP_NAME,TEAM_ROASTER.START_DATE,TEAM_ROASTER.END_DATE,PRIM_OR_SEC,TEAM_ROASTER.CG_EMP_ID FROM Team_info LEFT JOIN TEAM_ROASTER ON Team_info.CG_EMP_ID = TEAM_ROASTER.CG_EMP_ID ",(err,rows,fields)=>{
        if(!err)
        res.send(rows.recordset);
        else
        res.send(err);
    })
});
// app.get('/lms',(req,res)=>{
//     sqlserverconnection.query('SELECT * FROM LEAVE_PLAN',(err,rows,fields)=>{
//         if(!err)
//          res.send(rows.recordset);
//          else        
//          res.send(err);
//      })
//  });

app.get('/lms',(req,res)=>{
    sqlserverconnection.query("SELECT EMP_NAME,START_DATE,END_DATE,LEAVE_PLAN.CG_EMP_ID FROM Team_info LEFT JOIN LEAVE_PLAN ON Team_info.CG_EMP_ID = LEAVE_PLAN.CG_EMP_ID ",(err,rows,fields)=>{
        if(!err)
                 res.send(rows.recordset);
         else
         res.send(err);
     })
});
// inserting Team roaster

app.post('/teamroaster',(req,res)=>{
    let employee=req.body;
    console.log(employee);
    sqlserverconnection.query("insert into team_roaster values("+employee.CG_EMP_ID+','+"'"+employee.Start_Date+"'"+','+"'"+employee.End_Date+"'"+','+"'"+employee.PRIM_OR_SEC+"'"+");",(err,rows,fields)=>{
    //sqlserverconnection.query(sql,parameters,(err,rows,fields)=>{
    if(!err)
    res.send(rows.count);
    else
    res.send(err);
    })
    }); 
    app.post('/lms',(req,res)=>{
        let employee=req.body;
        console.log(employee);
        sqlserverconnection.query("insert into LEAVE_PLAN values("+employee.CG_EMP_ID+','+"'"+employee.Start_Date+"'"+','+"'"+employee.End_Date+"'"+','+"'"+");",(err,rows,fields)=>{
        //sqlserverconnection.query(sql,parameters,(err,rows,fields)=>{
        if(!err)
        res.send(rows.count);
        else
        res.send(err);
        })
    }); 

