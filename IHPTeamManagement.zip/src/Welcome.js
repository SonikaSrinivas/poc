import React, { Component } from "react";
import "./Home.css";
import TeamInfo from './TeamInfo';


export default class Welcome extends Component {
  
  render() {
    return (
      <div className="Home">
      
      <div className="lander">
      <TeamInfo history={this.props.history}/>
      </div>
      </div>
    );
  }
}
