import React, { Component } from "react";
import "./Home.css";
import team2 from './cap.jpg';



export default class Home extends Component {
  

  render() {
     return (
     
      <div className="image">
     <img src={team2}></img>
      </div>
  );
}
}
