

import React from 'react';
import Slider from 'react-animated-slider';
import 'react-animated-slider/build/horizontal.css';

import Team from '../ethnic/IMG-20190405-WA0054.jpg';
import pic from '../ethnic/IMG-20190405-WA0077.jpg';
import pic1 from '../ethnic/IMG-20190405-WA0056.jpg';
import pic2 from '../ethnic/IMG-20190405-WA0022.jpg';
import pic3 from '../ethnic/IMG-20190405-WA0013.jpg';
import pic4 from '../ethnic/IMG-20190405-WA0021.jpg';
import pic5 from '../ethnic/IMG-20190405-WA0142.jpg';
import pic6 from '../ethnic/IMG-20190405-WA0035.jpg';
import pic7 from '../ethnic/IMG-20190405-WA0047.jpg';
import '../ethnic.css';



class Ethnic extends React.Component
{

render(){

return(
  
    <div className="container">
    <h4 align="center"><u>Ugadi Ethinic day Celebrations</u>  (15th April-2019)</h4>
<Slider  right-align='1500px'>
<img src={Team} align="auto" height="500px"></img>
<img src={pic} align="auto"></img>
<img src={pic1} align="auto"></img>
<img src={pic2} align="auto"></img>
<img src={pic3} align="auto"></img>
<img src={pic4} align="auto"></img>
<img src={pic5} align="auto"></img>
<img src={pic6} align="auto"></img>
<img src={pic7} align="auto"></img>
</Slider>
</div>

);
}

}
export default Ethnic

