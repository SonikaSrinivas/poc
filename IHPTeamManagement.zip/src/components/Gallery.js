

import React from 'react';

import img1 from '../img/img1.jpg';
import Anu from '../img/Anu.jpg';
import Ranjit from '../img/Ranjit.jpg';
import Bala from '../img/Bala.jpg';
import Hari from '../img/hari.jpg';
import Harika from '../img/harika.jpg';
import Nagraj from '../img/Nagraj.jpg';
import Anup from '../img/Anup.jpg';
import Praveen from '../img/Praveen.jpg';
import Murali from'../img/murali.jpg';
import Ashraf from '../img/Ashraf.jpg';
import Amit from '../img/Amit.jpg';
import subha from '../img/Subha.jpg';
import Preeti from '../img/Preeti.jpg';
import Soni from '../img/sonika.jpg';
import Sushma from '../img/sushma.jpg';
import deep from '../img/dp.jpg';
import vidya from '../img/vidya.jpg';
import Amba from '../img/amba.jpg';
import Sonali from '../img/sonali.jpg';


import "../table.css";
class Gallery extends React.Component
{

render(){

    return(
        <div>
        <h4 align="center"><u> IHP Team Members</u></h4>
        <br/><br/>
       <table id="skilltable" align="center">
          <tr>
              
           <th></th>
              <th><img src={Nagraj}  width="120" height="150"></img></th>
              <th><img src={Praveen}  width="120" height="150"></img></th>
              <th><img src={Anup}  width="120" height="150"></img></th>
              
              <th><img src={Murali}  width="120" height="150"></img></th>
              <th><img src={Ashraf}  width="120" height="150"></img></th>
              <th><img src={Sonali} width="120" height="150"></img></th>
          </tr>
          <tr>
              <th></th>
        <th>
        <p align="center">Nagaraj DS</p>
        </th>
        <th>
        <p align="center">Praveen Reddy</p>
        </th>
        <th>
        <p align="center">Anup Chakraborty</p>
        </th>
       
        <th>
        <p align="center">Murali Papareddy</p>
        </th>
        <th>
        <p align="center">Ashraful Abedin</p>
        </th>
        <th>
        <p align="center">Sonali mohapatra</p>
        </th>
        </tr>
       
        
        <tr>
            <td></td>
        <td><p align="center">(Manager)</p></td>
        <td><p align="center">(Manager)</p></td>
        <td><p align="center">(Senior Consultant)</p></td>
       
        <td><p align="center">(Senior Consultant)</p></td>
        <td><p align="center">(Senior Consultant)</p></td>
        <td><p align="center">(Consultant)</p></td>

        </tr>

        <tr>  
            <th><img src={Hari}  width="120" height="150"></img></th>
            <th><img src={Amit}  width="120" height="150"></img></th>
            <th><img src={Preeti}  width="120" height="150"></img></th>
            <th><img src={subha}  width="120" height="150"></img></th>
            <th><img src={Ranjit}  width="120" height="150"></img></th>
            <th><img src={Bala}  width="120" height="150"></img></th>
            <th><img src={img1}  width="120" height="150"></img></th>
            
       
            
            </tr>
            <tr>
         
       <th>
       <p align="center">Harinath Reddy</p>
       </th>
        <th>
        <p align="center">Amit Singh</p>
        </th>
        <th>
        <p align="center">Preeti Hiramath</p>
        </th>
        <th>
        <p align="center">Shubhalaksmi Biradar</p>
        </th>
        <th>
       <p align="center">Ranjith Sahu</p>
       </th>
        <th>
        <p align="center">BalaKrishna Depani</p>
       </th>
       <th>
      <p align="center">Kavita Kumari</p>
      </th>
        
        </tr>
<tr>
        <td><p align="center">(Consultant)</p></td>
        <td><p align="center">(Consultant)</p></td>
        <td><p align="center">(Consultant)</p></td>
        <td><p align="center">(Consultant)</p></td>
        <td><p align="center">(Consultant)</p></td>
        <td><p align="center">(Consultant)</p></td>
        <td><p align="center">(Consultant)</p></td>
        </tr>     
        
        <tr>
        <th><img src={Anu}  width="120" height="150"></img></th>
        <th><img src={Harika}  width="120" height="150"></img></th>
        <th><img src={vidya}  width="120" height="150"></img></th>
        <th><img src={Soni}  width="120" height="150"></img></th>
        <th><img src={Amba}  width="120" height="150"></img></th>
        <th><img src={deep}  width="120" height="150"></img></th>
        <th><img src={Sushma}  width="120" height="150"></img></th>
       
       </tr>
       <tr>
       <th><p>Anushree M R</p></th>
       <th><p align="center">Harika Yerram</p></th>
       <th><p align="center">Vidyasailaja kosuri</p></th>
       <th><p align="center">Sonika S</p></th>
       <th><p align="center">Amba Mukherjee</p></th>
       <th><p align="center">Deepjyoti Bhattacharjee</p></th>
       <th><p align="center">Sushma</p></th>
     </tr>
     <tr>
         <td>
         <p align="center">(Associate Consultant)</p>
         </td>
         <td>
       <p align="center">(Associate Consultant)</p>
         </td>
         <td>
         <p align="center">(Associate Consultant)</p>
         </td>
         <td>
         <p align="center">(Software Engineer)</p>
         </td>
         <td>
         <p align="center">(Software Engineer)</p>
         </td>
         <td>
         <p align="center">(Software Engineer)</p>
         </td>
         <td>
         <p align="center">(Software Engineer)</p>
         </td>
       </tr>
      
        </table>
        </div>
    )
}

}



export default Gallery