
import React, { Component } from 'react';


import "../table.css";

export default class CreateSkillProficiency extends Component {

    constructor(props) {
        super(props);
        this.state = {
            planets: [],
            planets1:[],
            planet2:[],
            skills: [],
            skills1:[],
            skill2:[],
            empList: 1,
            cg_emp_id: sessionStorage.getItem("cgempid"),
            cg_emp_id1:sessionStorage.getItem("cgempid"),
            cg_emp_id2:sessionStorage.getItem("cgempid"),
            skill_id: '',
            proficiency: '',
            last_used: '',
            experience: '',
            skill_id1:'',
            proficiency1:'',
            last_used1:'',
            experience1:'',
            skill_id2:'',
            proficiency2:'',
            last_used2:'',
            experience2:'',
        }

        this.onChangeCGempId = this.onChangeCGempId.bind(this);
        this.onChangeCGempId1 = this.onChangeCGempId1.bind(this);
        this.onChangeCGempId2 = this.onChangeCGempId2.bind(this);
        this.onChangeSkillId = this.onChangeSkillId.bind(this);
        this.onChangeSkillId1 = this.onChangeSkillId1.bind(this);
        this.onChangeSkillId2 = this.onChangeSkillId2.bind(this);
       
        this.handleChange = this.handleChange.bind(this);
        this.handleChange1=this.handleChange1.bind(this);
        this.handleChange2=this.handleChange2.bind(this);
        this.onSubmit = this.onSubmit.bind(this);

    }

    onChangeCGempId(e) {
        var index = e.target.selectedIndex;
     
        this.setState({

            cg_emp_id: e.target.childNodes[index].getAttribute('data-id')
        });

      console.log(this.state.cg_emp_id);
    }


    onChangeCGempId1(e) {
        var index = e.target.selectedIndex;
     
        this.setState({

            cg_emp_id1: e.target.childNodes[index].getAttribute('data-id')
        });

      console.log(this.state.cg_emp_id1);
    }

    onChangeCGempId2(e) {
        var index = e.target.selectedIndex;
     
        this.setState({

            cg_emp_id2: e.target.childNodes[index].getAttribute('data-id')
        });

      console.log(this.state.cg_emp_id2);
    }

    onChangeSkillId(e) {
        var index = e.target.selectedIndex;
        console.log(e.target.childNodes[index].getAttribute('skill-id'));

        this.setState({
            skill_id: e.target.childNodes[index].getAttribute('skill-id')

        });

        console.log(this.state.skill_id);
    }

    
    onChangeSkillId1(e) {
        var index = e.target.selectedIndex;
        console.log(e.target.childNodes[index].getAttribute('skill-id'));

        this.setState({
            skill_id1: e.target.childNodes[index].getAttribute('skill-id')

        });

        console.log(this.state.skill_id1);
    }

     
    onChangeSkillId2(e) {
        var index = e.target.selectedIndex;
        console.log(e.target.childNodes[index].getAttribute('skill-id'));

        this.setState({
            skill_id2: e.target.childNodes[index].getAttribute('skill-id')

        });

        console.log(this.state.skill_id2);
    }

    handleChange = event => {

        this.setState({
            [event.target.id]: event.target.value
        });
      }


    handleChange1 = event=> {

        this.setState({
            [event.target.id]: event.target.value
        });
     }

     
    handleChange2 = event=> {

        this.setState({
            [event.target.id]: event.target.value
        });
     }

    componentDidMount() {

        fetch("http://localhost:5000/getEmployeeName")
            .then(res => res.json())
            .then(data => {
                this.setState({
                    planets: data

                });
                console.log(data.recordset[0]);
            })
            .catch(err => console.error);

        fetch("http://localhost:5000/skillslist")
            .then(res => res.json())
            .then(data => {
                this.setState({
                    skills: data

                });
                console.log(data.recordset[0]);
            })
            .catch(err => console.error);


    }


    onSubmit(e) {
        e.preventDefault();
        alert("Record has been submitted");

        fetch('http://localhost:5000/createSkillproficiency',
            {

                method: 'POST',
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json'
                },

             

                body: JSON.stringify(
                {
                
                    "cg_emp_id": parseInt(this.state.cg_emp_id),
                    "skill_id": parseInt(this.state.skill_id),
                    "proficiency": this.state.proficiency,
                    "last_used": this.state.last_used,
                    "experience": parseInt(this.state.experience),
                    "cg_emp_id1": parseInt(this.state.cg_emp_id1),
                    "skill_id1": parseInt(this.state.skill_id1),
                    "proficiency1": this.state.proficiency1,
                    "last_used1": this.state.last_used1,
                    "experience1": parseInt(this.state.experience1),
                    "cg_emp_id2": parseInt(this.state.cg_emp_id2),
                    "skill_id2": parseInt(this.state.skill_id2),
                    "proficiency2": this.state.proficiency2,
                    "last_used2": this.state.last_used2,
                    "experience2": parseInt(this.state.experience2)
                    }
                ),

            }).then(res => res.json())
            .then(resData => {
                console.log(resData);
                this.setState({
                    cg_emp_id: '',
                    skill_id: '',
                    proficiency: '',
                    last_used: '',
                    experience: '',
                    cg_emp_id1: '',
                    skill_id1: '',
                    proficiency1: '',
                    last_used1: '',
                    experience1: '',
                    cg_emp_id2: '',
                    skill_id2: '',
                    proficiency2: '',
                    last_used2: '',
                    experience2: '',
                
                   })



                // this.fetchOrders();
            }).catch(err => console.error);

    }

    render() {
        let emps = this.state.planets;
        //console.log(emps);
        let optionItems_employee = emps.map((planet) =>
            <option value={planet.EMP_NAME} data-id={planet.CG_EMP_ID} key={planet.CG_EMP_ID}>{planet.EMP_NAME}</option>

        );

        let emps1 = this.state.planets;
        //console.log(emps);
        let optionItems_employee1 = emps1.map((planet1) =>
            <option value={planet1.EMP_NAME} data-id={planet1.CG_EMP_ID} key={planet1.CG_EMP_ID}>{planet1.EMP_NAME}</option>

        );

      
        let emps2 = this.state.planets;
        //console.log(emps);
        let optionItems_employee2 = emps2.map((planet2) =>
            <option value={planet2.EMP_NAME} data-id={planet2.CG_EMP_ID} key={planet2.CG_EMP_ID}>{planet2.EMP_NAME}</option>

        );

        let skill = this.state.skills;
        // console.log(skill);
        let optionItems_skills = skill.map((empskill) =>
            <option value={empskill.SKILL} skill-id={empskill.SKILL_ID} key={empskill.SKILL_ID}>{empskill.SKILL}</option>

        );

        let skill1 = this.state.skills;
        // console.log(skill);
        let optionItems_skills1 = skill1.map((empskill1) =>
            <option value={empskill1.SKILL} skill-id={empskill1.SKILL_ID} key={empskill1.SKILL_ID}>{empskill1.SKILL}</option>

        );

        let skill2 = this.state.skills;
        // console.log(skill);
        let optionItems_skills2 = skill2.map((empskill2) =>
            <option value={empskill2.SKILL} skill-id={empskill2.SKILL_ID} key={empskill2.SKILL_ID}>{empskill2.SKILL}</option>

        );

      


        return (

            <div>
                <br />
                <h4 align="center"><u>Add Skill Proficiency</u></h4>
                <br /><br />

                <form onSubmit={this.onSubmit}>
                    <table id="skilltable" align="center">

                        <tr>
                            <th>Name</th>
                            <th>Skills</th>
                            <th>Proficiency</th>
                            <th>Last Used</th>
                            <th>Exp(Months)</th>

                        </tr>

                        {((sessionStorage.getItem("userRole") === "Admin"))
                            ? <td>
                                <div className="firstLabel">
                                    <select value={this.state.value} onChange={this.onChangeCGempId} >
                                        {optionItems_employee}
                                    </select>
                                </div>
                            </td> :
                            <td>
                                <div className="firstLabel">
                                    <select onChange={this.onChangeCGempId} >
                                        <option> {sessionStorage.getItem("userName")}</option>
                                    </select>
                                </div>
                            </td>}





                        <td>
                            <div className="firstLabel">
                                <select value={this.state.value}  onChange={this.onChangeSkillId}>
                                   <option>Select Skill</option> 
                                    {optionItems_skills}
                                </select>
                            </div>
                        </td>


                        <td>
                            <div className="firstLabel">
                                <select value={this.state.proficiency} onChange={this.handleChange} id="proficiency">
                                <option value="0" selected="selected">Select Value</option>
                                   <option>No knowledge</option>
                                    <option>Beginner</option>
                                    <option>Moderate</option>
                                    <option>Good</option>
                                    <option>Expert</option>
                                    <option>Attended Basic Training</option>
                                </select>
                            </div>
                        </td>

                        <td>
                            <div className="firstLabel">
                                <input type="text" value={this.state.last_used} onChange={this.handleChange} id="last_used" />
                            </div>
                        </td>

                        <td>
                            <div className="firstLabel">
                                <input type="text" value={this.state.experience} onChange={this.handleChange} id="experience" />
                            </div>
                        </td>

                        <tr>  {((sessionStorage.getItem("userRole") === "Admin"))
                            ? <td>
                                <div className="firstLabel">
                                    <select value={this.state.value} onChange={this.onChangeCGempId1} >
                                        {optionItems_employee1}
                                    </select>
                                </div>
                            </td> :
                            <td>
                                <div className="firstLabel">
                                    <select onChange={this.onChangeCGempId1} >
                                    <option> {sessionStorage.getItem("userName")}</option>
                                    </select>
                                </div>
                            </td>}

                            <td>
                                <div className="firstLabel">
                                    <select value={this.state.value} onChange={this.onChangeSkillId1}>
                                    <option>Select Skill</option> 
                                        {optionItems_skills1}
                                    </select>
                                </div>
                            </td>
                            <td>
                                <div className="firstLabel">
                                    <select value={this.state.proficiency1} onChange={this.handleChange1} id="proficiency1">
                                    <option value="0" selected="selected">Select Value</option>
                                        <option>No knowledge</option>
                                        <option>Beginner</option>
                                        <option>Moderate</option>
                                        <option>Good</option>
                                        <option>Expert</option>
                                        <option>Attended Basic Training</option>
                                    </select>
                                </div>
                            </td>

                            <td>
                                <div className="firstLabel">
                                    <input type="text" value={this.state.last_used1} onChange={this.handleChange1} id="last_used1" />
                                </div>
                            </td>

                            <td>
                                <div className="firstLabel">
                                    <input type="text" value={this.state.experience1} onChange={this.handleChange1} id="experience1" />
                                </div>
                            </td>


                        </tr>

                        <tr>  {((sessionStorage.getItem("userRole") === "Admin"))
                            ? <td>
                                <div className="firstLabel">
                                    <select value={this.state.value} onChange={this.onChangeCGempId2} >
                                        {optionItems_employee2}
                                    </select>
                                </div>
                            </td> :
                            <td>
                                <div className="firstLabel">
                                    <select onChange={this.onChangeCGempId2} >
                                        <option> {sessionStorage.getItem("userName")}</option>
                                    </select>
                                </div>
                            </td>}

                            <td>
                                <div className="firstLabel">
                                    <select value={this.state.value} onChange={this.onChangeSkillId2}>
                                    <option>Select Skill</option> 
                                        {optionItems_skills2}
                                    </select>
                                </div>
                            </td>
                            <td>
                                <div className="firstLabel">
                                    <select value={this.state.proficiency2} onChange={this.handleChange2} id="proficiency2">
                                    <option value="0" selected="selected">Select Value</option>
                                        <option>No knowledge</option>
                                        <option>Beginner</option>
                                        <option>Moderate</option>
                                        <option>Good</option>
                                        <option>Expert</option>
                                        <option>Attended Basic Training</option>
                                    </select>
                                </div>
                            </td>

                            <td>
                                <div className="firstLabel">
                                    <input type="text" value={this.state.last_used2} onChange={this.handleChange2} id="last_used2" />
                                </div>
                            </td>

                            <td>
                                <div className="firstLabel">
                                    <input type="text" value={this.state.experience2} onChange={this.handleChange2} id="experience2" />
                                </div>
                            </td>
                        </tr>
                    </table>
                    <br />
                    <p align="center"> <input type="submit" value="Add Skill Proficiency"  id="button"  onSubmit={this.onSubmit} /></p>
                </form><br />
            </div>
        )
    }
}

