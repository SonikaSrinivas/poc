import React, { Component } from "react";
import "./Home.css";



export default class SignUpSuccess extends Component {
  
  render() {
    return (
     <div className="Home">
        <div className="lander">
          <h2>Employee Portal</h2>
          Hi {this.props.location.state.username}.
          You are registered successfully
         
          {/* <h1>Welcome {this.props.location.state.username}</h1> */}
          
          
        </div>
      </div>
    );
  }
}
