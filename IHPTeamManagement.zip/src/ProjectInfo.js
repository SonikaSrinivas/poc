import React, { Component } from "react";
import ReactToExcel from "react-html-table-to-excel";
//import  ActionCells from '/.ActionCells.js';

//import './App.css';
import './table.css';

class ProjectInfo extends Component
{
  constructor(props, context) {
    super(props, context);
    this.state = {
        projectinfo: [],
        
        };
   
}
  componentDidMount(){
    fetch("http://localhost:5000/projectinfo")
            .then(res => res.json())
            .then(data => {
               this.setState({
                projectinfo: data
                
            }); 
              //console.log(data.recordset[0]);
            })
            .catch(err => console.error);
  }

  /*fetchData = event => {
    event.preventDefault();
    console.log("Fetching");
    fetch("http://localhost:5000/projectinfo")
            .then(res => res.json())
            .then(data => {
               this.setState({
                projectinfo: data
                
            }); 
              //console.log(data.recordset[0]);
            })
            .catch(err => console.error);
  }  */ 
  
  render(){
      console.log(this.state.projectinfo);
 return (
    <div className="container">
       <h4 align="center"><u>Project Information</u></h4>
    <table className="table table-striped" id="table-to-xls" table border="1">
    <thead>
    <tr class="tabletemplate">
          <th>Project Code </th>
          <th>Project Description </th>
          <th>Start Date</th>
          <th>End Date</th>
          <th>Active</th>
          <th></th>
          <th></th>
      </tr>
      </thead>
      <tbody>
      {this.state.projectinfo.map(row => (
        <tr key={row.id}>
          
          <td>{row.PROJECT_CD}</td>
          <td>{row.PROJECT_DESC}</td>
          <td>{row.START_DATE.slice(0,-14)}</td>
          <td>{row.END_DATE.slice(0,-14)}</td>
          <td>{row.ACTIVE}</td>
          <td><button className="btn btn-primary">Edit</button></td>
          <td><button onClick={() => this.deleteUser(row.id)} className="btn btn-danger">Delete</button></td>

        </tr>
      ))}
      </tbody>
      </table> 
      <ReactToExcel 
        className="btn"
        table="table-to-xls"
        filename="ProjectInfo"
        sheet="sheet 1"
        buttonText="Export"
        />
    </div>
  );

}

}
export default ProjectInfo;

