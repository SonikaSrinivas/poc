import React, { Component, Fragment } from "react";

import './App.css';
import { Link, withRouter } from "react-router-dom";
import { LinkContainer } from "react-router-bootstrap";
import Routes from "./Routes";
import { Nav, Navbar, NavItem,NavDropdown } from "react-bootstrap";
// import Signup from "./Signup";


import logo from './logo.svg';


class App extends Component {
  constructor(props) {
    super(props);
  
    this.state = {
      isAuthenticated: false,
      isAuthenticating: true,
      userRoles:""
      

    };
  }
  async componentDidMount() {

   
    /* try {
      //await Auth.currentSession();
      //this.userHasAuthenticated(true);
    }
    catch(e) {
      if (e !== 'No current user') {
        alert(e);
      }
    } */
  
    this.setState({ isAuthenticating: false });
  }
  
  
  userHasAuthenticated = (authenticated,userRole) => {
    this.setState({ isAuthenticated: authenticated ,userRoles:userRole});
   
  }
  
  handleLogout = event => {
    fetch("http://localhost:5000/logout")
    .then(res => res.json())
    this.userHasAuthenticated(false,null);
    sessionStorage.removeItem("userName");
    this.props.history.push("/login");
    
    } 
  
  render() {
    const childProps = {
      isAuthenticated: this.state.isAuthenticated,
      userHasAuthenticated: this.userHasAuthenticated,
      
    };
  
    return (
      !this.state.isAuthenticating &&
      <div className="App container">
        <Navbar fluid collapseOnSelect>
          <Navbar.Header>
          {this.state.isAuthenticated && (this.state.userRoles==="Admin" || this.state.userRoles==="User" )
                ? 
            <Navbar.Brand>
              <Link to="/">Home</Link><br/>
             <p class="msg">Welcome {sessionStorage.getItem("userName")} ({sessionStorage.getItem("userRole")})</p>
            </Navbar.Brand>:
            <Navbar.Brand><Link to="/">Home</Link>
         </Navbar.Brand> 
         
    }
          <Navbar.Toggle />
          </Navbar.Header>
          <Navbar.Collapse>
            <Nav pullRight>
              {this.state.isAuthenticated && this.state.userRoles==="Admin"
                ? 
                <Fragment>
                  <NavDropdown title="Info">
                  <LinkContainer to="/ProjectInfo"><NavItem>ProjectInfo</NavItem></LinkContainer>
                  <LinkContainer to="/TeamInfo"><NavItem>TeamInfo</NavItem></LinkContainer>
                  </NavDropdown>
                  <NavDropdown title="Leave and Roaster">
                  <LinkContainer to="/lms"><NavItem>Leave Management System</NavItem></LinkContainer>
                  <LinkContainer to="/shiftroaster"><NavItem>Shift Roaster</NavItem></LinkContainer>
                  </NavDropdown>
                  <NavDropdown title="Skill Proficiency">
                 <LinkContainer to="/CreateSkillProficiency"><NavItem>Create Skill Proficiency</NavItem></LinkContainer>
               <LinkContainer to="/ViewSkillProficiency"><NavItem>View Skill Proficiency</NavItem></LinkContainer>
               <LinkContainer to="/SkillMatrix"><NavItem>Skill Matrix</NavItem></LinkContainer>
              </NavDropdown>
              <NavDropdown title="Team Gallery">
              <LinkContainer to="/Gallery"><NavItem>Introducing Our Team</NavItem></LinkContainer>
              <LinkContainer to="/Ethnic"><NavItem>Ethnic Day Pics</NavItem></LinkContainer>
              <LinkContainer to="/Christmas"><NavItem>Christmas Pics</NavItem></LinkContainer>
              </NavDropdown>

                <NavItem onClick={this.handleLogout}>Logout</NavItem></Fragment>
                :(this.state.isAuthenticated && this.state.userRoles==="User") 
                ?<Fragment>
                  <NavDropdown title="Info">
                  <LinkContainer to="/ProjectInfo"><NavItem>ProjectInfo</NavItem></LinkContainer>
                  <LinkContainer to="/TeamInfo"><NavItem>TeamInfo</NavItem></LinkContainer> 
                  </NavDropdown>
                  <NavDropdown title="Leave and Roaster">
                  <LinkContainer to="/lms"><NavItem>Leave Management System</NavItem></LinkContainer>
                  <LinkContainer to="/shiftroaster"><NavItem>Shift Roaster</NavItem></LinkContainer>
                  </NavDropdown>
                  <NavDropdown title="Skill Proficiency">
                  <LinkContainer to="/CreateSkillProficiency"><NavItem>Create Skill Proficiency</NavItem></LinkContainer>
               <LinkContainer to="/ViewSkillProficiency"><NavItem>View Skill Proficiency</NavItem></LinkContainer>
              </NavDropdown>
              <NavDropdown title="Team Gallery">
              <LinkContainer to="/Gallery"><NavItem>Introducing Our Team</NavItem></LinkContainer>
              <LinkContainer to="/Ethnic"><NavItem>Ethnic Day Pics</NavItem></LinkContainer>
              <LinkContainer to="/Christmas"><NavItem>Christmas Pics</NavItem></LinkContainer>
              </NavDropdown>

                <NavItem onClick={this.handleLogout}>Logout</NavItem></Fragment>
                :<Fragment>
                    <LinkContainer to="/signup">
                      <NavItem className="fragment">Signup</NavItem>
                    </LinkContainer>
                    <LinkContainer to="/login">
                      <NavItem>Login</NavItem>
                    </LinkContainer>
                  </Fragment>
              }
            </Nav>
          </Navbar.Collapse>
          </Navbar>
         

        <Routes childProps={childProps} />
        <footer class="page-footer font-small mdb-color darken-3 pt-4">
        <div class="container">
        <div class="row d-flex justify-content-center">
         <div class="col-md-6">
         <div class="embed-responsive embed-responsive-16by9 mb-4">
         </div>
        </div>
        </div>
           </div>
        <div class="footer-copyright text-center py-3">© 2019 Copyright:
    <b><a class="copyright" href="https://www.capgemini.com/"> capgemini.com</a></b>
    </div>
   </footer>
      </div>
    );
  }
  
  
  
  }


  export default withRouter(App);

