import React, { Component } from 'react';
import axios from 'axios';
class Notification  extends Component {
    constructor() {
        super();
        this.serviceUrl = "http://localhost:5000/api/event/"; 
        this.state = { 
            event: []
     } 
     this.onChangePage = this.onChangePage.bind(this);
    }
    onChangePage(pageOfItems) {
        // update state with new page of items
        this.setState({ pageOfItems: pageOfItems });
    }
    componentDidMount() {
        let _id = this.props.match.params._id;
        axios.get(this.serviceUrl + _id).then((res) => {
           this.setState({
              event: res.data
           })
        })
     }
    render() { 
        return (
            <div className="well">
            <h1> Notification of Upcoming events </h1> <hr/><br/>
            <table className="table table-dark table-stripped">
                <tr><th>Index</th><th>Event Name</th><th>Start Date</th><th>Start Date Time</th><th>End Date</th><th>End Date Time</th><th>Registration Start Date</th><th>Registration Start Time</th><th>Registrtion End Date</th><th>Registration End Time</th></tr>
                {this.state.event.map((j, i)=><tr><td>{j._id}</td><td>{j.eventname}</td><td>{j.start}</td><td>{j.stime}</td><td>{j.end}</td><td>{j.etime}</td><td>{j.regstart}</td><td>{j.regstime}</td><td>{j.regend}</td><td>{j.regetime}</td>
    </tr>)}
        
            </table>
        </div> );
    }
}
 




export default Notification;  